package com.example.developer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
