import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../views/Account/AccountScreen.dart';
import '../views/ServiceProvider/ServiceProviderHomeScreen.dart';
import '../views/ServiceProvider/WorkerMyHireScreen.dart';
import '../views/User/MyHireScreen.dart';
import '../views/User/UserHomeScreen.dart';

class Bottombar extends StatefulWidget {
  const Bottombar({super.key});

  @override
  State<Bottombar> createState() => _BottombarState();
}

class _BottombarState extends State<Bottombar> {
  int _currentIndex = 0;
  String? myrole;

  late List<Widget> _userScreens;
  late List<Widget> _serviceProviderScreens;

  Future<void> getRole() async {
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('role') ?? '';
    final categoryId = prefs.getString('category_id');
    final subCategoryId = prefs.getString('sub_category_id');

    print("Abhi:- get role in bottombar screen 1: $role");
    print("Abhi:- category_id: $categoryId, sub_category_id: $subCategoryId");

    setState(() {
      myrole = role;

      _userScreens = [
        const UserHomeScreen(), // 0
        const MyHireScreen(), // 1
        const PlaceholderScreen(label: 'My Work'), // 2
        const PlaceholderScreen(label: 'Message'), // 3
        const AccountScreen(), // 4
      ];

      _serviceProviderScreens = [
        const ServiceProviderHomeScreen(), // 0
        const PlaceholderScreen(label: 'My Hire'), // 1
        WorkerMyHireScreen(
          // 👇 Fixed: parameters passed
          categreyId: categoryId,
          subcategreyId: subCategoryId,
        ),
        const PlaceholderScreen(label: 'Message'), // 3
        const AccountScreen(), // 4
      ];
    });
  }

  @override
  void initState() {
    super.initState();
    getRole();
  }

  @override
  Widget build(BuildContext context) {
    if (myrole == null || myrole!.isEmpty) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    print("Abhi:- get role in bottom bar screen 2: $myrole");

    List<Widget> selectedScreens;

    if (myrole == "service_provider") {
      selectedScreens = _serviceProviderScreens;
    } else if (myrole == "user") {
      selectedScreens = _userScreens;
    } else {
      return const Scaffold(body: Center(child: Text("Unknown role")));
    }

    return Scaffold(
      body: selectedScreens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.black,
        onTap: (index) {
          print("Tab Clicked: $index");
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage('assets/images/home.png'), size: 24),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage('assets/images/Message.png'), size: 24),
            label: 'My Hire',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage('assets/images/Job.png'), size: 24),
            label: 'My Work',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage('assets/images/Work.png'), size: 24),
            label: 'Message',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage('assets/images/Account.png'), size: 24),
            label: 'Account',
          ),
        ],
      ),
    );
  }
}

class PlaceholderScreen extends StatelessWidget {
  final String label;

  const PlaceholderScreen({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(label)),
      body: Center(child: Text('$label Screen')),
    );
  }
}
