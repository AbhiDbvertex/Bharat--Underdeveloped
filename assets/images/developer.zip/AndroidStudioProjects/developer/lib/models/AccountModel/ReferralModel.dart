class ReferralModel {
  final String name;
  final String date;
  final String amount;

  ReferralModel({required this.name, required this.date, required this.amount});
}
