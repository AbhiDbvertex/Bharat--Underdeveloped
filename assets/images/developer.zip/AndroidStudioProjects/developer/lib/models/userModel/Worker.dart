class Worker {
  final String name;
  final String role;
  final double rating;

  const Worker({required this.name, required this.role, required this.rating});
}
