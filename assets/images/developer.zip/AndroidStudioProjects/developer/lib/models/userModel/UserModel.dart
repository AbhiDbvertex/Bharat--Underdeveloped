class User {
  final String phoneNumber;

  User({required this.phoneNumber});
}
