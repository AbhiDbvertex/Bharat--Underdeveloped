class DirectOrder {
  final String id;
  final String title;
  final String description;
  final String date;
  final String status;
  final String image;
  final String providerId; // 👈 Add this

  DirectOrder({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.status,
    required this.image,
    required this.providerId, // 👈 Add this
  });

  factory DirectOrder.fromJson(Map<String, dynamic> json) {
    return DirectOrder(
      id: json['_id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      date: (json['deadline'] ?? '').toString().substring(0, 10),
      status: json['hire_status'] ?? 'pending',
      image: 'https://api.thebharatworks.com${json['image_url'] ?? ''}',
      providerId: json['provider_id'] ?? '', // 👈 Add this
    );
  }
}
