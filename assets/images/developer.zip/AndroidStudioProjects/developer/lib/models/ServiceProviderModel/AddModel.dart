class AddModel {
  String name;
  String phoneNumber;
  String aadhaar;
  String dob;
  String address;

  AddModel({
    required this.name,
    required this.phoneNumber,
    required this.aadhaar,
    required this.dob,
    required this.address,
  });
}
