class AppConstants {
  static const String baseUrl = 'https://api.thebharatworks.com/api';
  static const String baseImageUrl = 'https://api.thebharatworks.com';
}
