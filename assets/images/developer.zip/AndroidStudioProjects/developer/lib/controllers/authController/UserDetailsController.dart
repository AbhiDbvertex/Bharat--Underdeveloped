import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class UserDetailsController {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController landmarkController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController currentLocationController =
      TextEditingController();
  final TextEditingController fullAddressController = TextEditingController();
  final TextEditingController colonyNameController = TextEditingController();
  final TextEditingController houseNumberController = TextEditingController();
  final TextEditingController referralController = TextEditingController();
  final TextEditingController roleController = TextEditingController();

  String? selectedCategoryId;
  String? selectedSubCategoryId;

  final Map<String, String?> _errorTexts = {};
  Map<String, String?> get errorTexts => _errorTexts;

  /// 🟩 Set role based on UI label
  void setRole(String selectedLabel) {
    const roleMap = {
      'User': 'user',
      'Service Provider': 'service_provider',
      'Business': 'service_provider', // ✅ Business is also service_provider
    };
    roleController.text = roleMap[selectedLabel] ?? selectedLabel.toLowerCase();
  }

  /// ✅ Validate user input before submission
  bool validateForm(BuildContext context) {
    _errorTexts.clear();

    if (nameController.text.isEmpty)
      _errorTexts['name'] = 'Name cannot be empty';
    if (landmarkController.text.isEmpty)
      _errorTexts['landmark'] = 'Landmark cannot be empty';
    if (locationController.text.isEmpty)
      _errorTexts['location'] = 'Location cannot be empty';
    if (currentLocationController.text.isEmpty)
      _errorTexts['currentLocation'] = 'Please select your current location';
    if (fullAddressController.text.isEmpty)
      _errorTexts['fullAddress'] = 'Full address required';
    if (colonyNameController.text.isEmpty)
      _errorTexts['colonyName'] = 'Colony name is required';
    if (houseNumberController.text.isEmpty)
      _errorTexts['houseNumber'] = 'House/Gali number required';

    return _errorTexts.isEmpty;
  }

  /// 🚀 Submit profile to API
  Future<bool> submitUserProfile(BuildContext context) async {
    if (!validateForm(context)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("❗ Please fill all required fields")),
      );
      return false;
    }

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null || token.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("User not authenticated. Please login again."),
        ),
      );
      return false;
    }

    final url = Uri.parse(
      'https://api.thebharatworks.com/api/user/updateUserProfile',
    );

    final body = {
      "full_name": nameController.text,
      "role": roleController.text,
      "location": locationController.text,
      "current_location": currentLocationController.text,
      "address": fullAddressController.text,
      "landmark": landmarkController.text,
      "colony_name": colonyNameController.text,
      "house_number": houseNumberController.text,
      "referral_code":
          referralController.text.isEmpty ? null : referralController.text,
      if (selectedCategoryId != null) "category_id": selectedCategoryId,
      if (selectedSubCategoryId != null)
        "subcategory_ids": [selectedSubCategoryId],
    };

    try {
      final response = await http.put(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(body),
      );

      final responseData = jsonDecode(response.body);

      final message =
          responseData['message'] ??
          (response.statusCode == 200 ? "Profile updated" : "Unknown error");
      final success = responseData['status'] == true;

      if (success) {
        // ✅ Save category and subcategory after success
        if (selectedCategoryId != null && selectedSubCategoryId != null) {
          await prefs.setString('category_id', selectedCategoryId!);
          await prefs.setString('sub_category_id', selectedSubCategoryId!);
          debugPrint("✅ Saved category_id: $selectedCategoryId");
          debugPrint("✅ Saved sub_category_id: $selectedSubCategoryId");
        } else {
          debugPrint("⚠️ category/subcategory is null, not saved.");
        }
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: success ? Colors.green : Colors.red,
        ),
      );

      return success;
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("❌ Error submitting profile: $e")));
      return false;
    }
  }

  /// 🧹 Clear all form fields
  void clearForm() {
    nameController.clear();
    landmarkController.clear();
    locationController.clear();
    currentLocationController.clear();
    fullAddressController.clear();
    colonyNameController.clear();
    houseNumberController.clear();
    referralController.clear();
    roleController.clear();
    selectedCategoryId = null;
    selectedSubCategoryId = null;
    _errorTexts.clear();
  }

  /// 🗑️ Dispose all controllers
  void dispose() {
    nameController.dispose();
    landmarkController.dispose();
    locationController.dispose();
    currentLocationController.dispose();
    fullAddressController.dispose();
    colonyNameController.dispose();
    houseNumberController.dispose();
    referralController.dispose();
    roleController.dispose();
  }
}
