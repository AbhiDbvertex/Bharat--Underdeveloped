import 'dart:convert';

import 'package:developer/Widgets/Bottombar.dart';
import 'package:developer/views/auth/RoleSelectionScreen.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Consent/ApiEndpoint.dart';
import '../../Consent/app_constants.dart';
import '../../models/OtpModel.dart';

class OtpController {
  final OtpModel model;

  final List<TextEditingController> textControllers = List.generate(
    4,
    (_) => TextEditingController(),
  );
  final List<FocusNode> focusNodes = List.generate(4, (_) => FocusNode());
  final List<AnimationController> animControllers = [];
  final List<Animation<double>> scaleAnimations = [];

  OtpController(this.model, TickerProvider vsync) {
    for (int i = 0; i < 4; i++) {
      final animCtrl = AnimationController(
        vsync: vsync,
        duration: const Duration(milliseconds: 200),
      );
      final animation = Tween<double>(
        begin: 1.0,
        end: 1.2,
      ).animate(CurvedAnimation(parent: animCtrl, curve: Curves.easeOut));
      animControllers.add(animCtrl);
      scaleAnimations.add(animation);
    }
  }

  void handleOtpInput(int index, String value, VoidCallback refreshUI) {
    if (value.length == 1) {
      model.otpDigits[index] = value;
      animControllers[index].forward().then(
        (_) => animControllers[index].reverse(),
      );
      if (index < 3) focusNodes[index + 1].requestFocus();
    } else if (value.isEmpty && index > 0) {
      focusNodes[index - 1].requestFocus();
    } else {
      model.otpDigits[index] = '';
    }
    refreshUI();
  }

  void updateOtp(String value) {
    for (int i = 0; i < 4; i++) {
      model.otpDigits[i] = (i < value.length) ? value[i] : '';
    }
  }

  /// ✅ VERIFY OTP API
  Future<void> verifyOtp(BuildContext context) async {
    final url = Uri.parse('https://api.thebharatworks.com/api/user/verifyOtp');
    final phone = model.phoneNumber.trim();
    final enteredOtp = model.otpDigits.join().trim();

    if (enteredOtp.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter complete 4-digit OTP")),
      );
      return;
    }

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'phone': phone, 'entered_otp': enteredOtp}),
      );

      print("Abhi:- API Response: ${response.body}");
      print("Abhi:- API Status Code: ${response.statusCode}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final message = data['message'] ?? "Success";
        final success = data['status'] == true;
        final token = data['token'];
        final isProfileComplete = data['isProfileComplete'] ?? false;
        final role = data['role'] ?? "";

        print("Abhi:- API role: $role : profile complete : $isProfileComplete");

        if (success && token != null) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('token', token);
          await prefs.setBool('isProfileComplete', isProfileComplete);
          await prefs.setString('role', role);

          // ✅ Fetch user profile and save category/subcategory
          await fetchAndSaveProfileData(token);

          // ✅ Navigation based on role and profile completion
          final existingRole = prefs.getString('role') ?? role;
          if (isProfileComplete &&
              (existingRole == "service_provider" || existingRole == "user")) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => Bottombar()),
              (route) => false,
            );
          } else if (isProfileComplete && existingRole == "both") {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => RoleSelectionScreen()),
              (route) => false,
            );
          } else {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => RoleSelectionScreen()),
              (route) => false,
            );
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message), backgroundColor: Colors.red),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Server error: ${response.statusCode}")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("❌ Error: $e")));
      print("Abhi:- verifyOtp error $e");
    }
  }

  /// Helper: Fetch profile from API and save category/subcategory to SharedPreferences
  Future<void> fetchAndSaveProfileData(String token) async {
    final profileResponse = await http.get(
      Uri.parse('${AppConstants.baseUrl}${ApiEndpoint.otpVerificationScreen}'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (profileResponse.statusCode == 200) {
      final profileData = jsonDecode(profileResponse.body);
      final profile = profileData['data'];

      final categoryId = profile['category_id'];
      final subCategoryIds = profile['subcategory_ids'];

      if (categoryId != null &&
          subCategoryIds != null &&
          subCategoryIds.isNotEmpty) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('category_id', categoryId);
        await prefs.setString('sub_category_id', subCategoryIds[0]);
        print("✅ Saved category_id: $categoryId");
        print("✅ Saved sub_category_id: ${subCategoryIds[0]}");
      } else {
        print("⚠️ category_id or sub_category_id missing in profile data");
      }
    } else {
      print(
        "❌ Failed to fetch profile data. Status: ${profileResponse.statusCode}",
      );
    }
  }

  /// ✅ RESEND OTP API
  Future<void> resendOtp(
    BuildContext context,
    TextEditingController pinController,
    VoidCallback refreshUI,
  ) async {
    final url = Uri.parse('https://api.thebharatworks.com/api/user/register');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'phone': model.phoneNumber}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final newOtp = data['temp_otp']?.toString() ?? '';
        model.actualOtpCode = newOtp;

        if (newOtp.length == 4) {
          model.otpDigits = newOtp.split('');
          pinController.text = newOtp;
          updateOtp(newOtp);
          refreshUI();
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Resend failed: ${response.body}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Network error: $e')));
    }
  }

  /// ✅ Dispose all controllers and nodes safely
  void dispose() {
    for (var controller in textControllers) {
      controller.dispose();
    }
    for (var node in focusNodes) {
      node.dispose();
    }
    for (var animCtrl in animControllers) {
      animCtrl.dispose();
    }
  }
}
