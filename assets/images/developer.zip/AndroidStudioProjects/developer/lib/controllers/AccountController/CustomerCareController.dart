import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Consent/ApiEndpoint.dart';
import '../../Consent/app_constants.dart';
import '../../models/AccountModel/CustomerCareModel.dart';

class CustomerCareController {
  final model = CustomerCareModel();

  final contactController = TextEditingController();
  final descriptionController = TextEditingController();

  void toggleContactMethod(bool isEmail) {
    model.isEmailSelected = isEmail;
  }

  void updateSubject(String? subject) {
    model.selectedSubject = subject;
  }

  bool validateForm(BuildContext context) {
    if (model.selectedSubject == null || contactController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all required fields')),
      );
      return false;
    }
    return true;
  }

  /// Contact via Email
  void emailForm(BuildContext context, VoidCallback refreshView) async {
    if (!validateForm(context)) return;

    model.contactDetail = contactController.text;
    model.description = descriptionController.text;

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Token missing. Please login again.')),
      );
      return;
    }

    final url = Uri.parse('${AppConstants.baseUrl}${ApiEndpoint.customerCare}');

    final body = {
      "subject": model.selectedSubject,
      "email": model.contactDetail,
      "message": model.description,
    };

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode(body),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Email submitted successfully!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Server Error: ${response.statusCode}\n${response.body}',
            ),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Request Error: $e')));
    }

    contactController.clear();
    descriptionController.clear();
    model.reset();
    refreshView();
  }

  /// Contact via Call
  void callForm(BuildContext context, VoidCallback refreshView) async {
    if (!validateForm(context)) return;

    model.contactDetail = contactController.text;
    model.description = descriptionController.text;

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Token missing. Please login again.')),
      );
      return;
    }

    final url = Uri.parse(
      'https://api.thebharatworks.com/api/CompanyDetails/contact/mobile',
    );

    final body = {
      "subject": model.selectedSubject,
      "mobile_number": model.contactDetail,
      "message": model.description,
    };

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode(body),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Call request submitted successfully!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Server Error: ${response.statusCode}\n${response.body}',
            ),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Request Error: $e')));
    }

    contactController.clear();
    descriptionController.clear();
    model.reset();
    refreshView();
  }
}
