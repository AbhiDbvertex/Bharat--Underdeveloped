import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EditWorkerController {
  final nameController = TextEditingController();
  final aadhaarController = TextEditingController();
  final addressController = TextEditingController();
  final dobController = TextEditingController();

  String? phoneNumber;
  File? selectedImage;

  String? nameError;
  String? phoneError;
  String? aadhaarError;
  String? dobError;
  String? addressError;

  bool validateFields() {
    bool isValid = true;

    nameError = nameController.text.trim().isEmpty ? 'Name is required' : null;
    if (nameError != null) isValid = false;

    phoneError =
        (phoneNumber == null || phoneNumber!.isEmpty)
            ? 'Phone is required'
            : null;
    if (phoneError != null) isValid = false;

    aadhaarError =
        aadhaarController.text.trim().isEmpty
            ? 'Aadhaar is required'
            : (!RegExp(r'^\d{12}$').hasMatch(aadhaarController.text.trim())
                ? 'Aadhaar must be 12 digits'
                : null);
    if (aadhaarError != null) isValid = false;

    dobError = dobController.text.trim().isEmpty ? 'DOB is required' : null;
    if (dobError != null) isValid = false;

    addressError =
        addressController.text.trim().isEmpty ? 'Address is required' : null;
    if (addressError != null) isValid = false;

    return isValid;
  }

  Future<bool> submitUpdateWorkerAPI(
    BuildContext context,
    String workerId,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null || token.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("🔐 Token not found. Please login again."),
        ),
      );
      return false;
    }

    final url = Uri.parse(
      "https://api.thebharatworks.com/api/worker/edit/$workerId",
    );
    final request = http.MultipartRequest('PUT', url);

    request.headers['Authorization'] = 'Bearer $token';
    request.headers['Accept'] = 'application/json';

    request.fields.addAll({
      'name': nameController.text.trim(),
      'phone': phoneNumber ?? '',
      'aadharNumber': aadhaarController.text.trim(),
      'dob': dobController.text.trim(),
      'address': addressController.text.trim(),
    });

    if (selectedImage != null && selectedImage!.existsSync()) {
      request.files.add(
        await http.MultipartFile.fromPath(
          'image',
          selectedImage!.path,
          contentType: MediaType('image', 'jpeg'),
        ),
      );
    }

    try {
      final response = await request.send();
      final respStr = await response.stream.bytesToString();

      print("Status: ${response.statusCode}");
      print("Response: $respStr");

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("✅ Worker updated successfully")),
        );
        return true;
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("❌ Update failed: $respStr")));
        return false;
      }
    } catch (e) {
      print("Exception: $e");
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("❌ Something went wrong")));
      return false;
    }
  }

  void dispose() {
    nameController.dispose();
    aadhaarController.dispose();
    addressController.dispose();
    dobController.dispose();
  }
}
