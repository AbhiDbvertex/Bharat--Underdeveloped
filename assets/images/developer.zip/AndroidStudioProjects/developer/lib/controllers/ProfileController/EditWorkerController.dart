import 'package:flutter/material.dart';

import '../../models/ServiceProviderModel/EditModel.dart';

class EditWorkerController {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final aadhaarController = TextEditingController();
  final dobController = TextEditingController();
  final addressController = TextEditingController();

  String? nameError;
  String? phoneError;
  String? aadhaarError;
  String? dobError;
  String? addressError;

  String? phoneNumber;

  bool validateFields() {
    bool isValid = true;

    if (nameController.text.trim().isEmpty) {
      nameError = 'Name is required';
      isValid = false;
    } else if (!RegExp(r'^[a-zA-Z ]+$').hasMatch(nameController.text.trim())) {
      nameError = 'Only alphabets allowed';
      isValid = false;
    } else {
      nameError = null;
    }

    if (phoneNumber == null || phoneNumber!.isEmpty) {
      phoneError = 'Phone number is required';
      isValid = false;
    } else if (!RegExp(r'^[0-9]{10}$').hasMatch(phoneNumber!)) {
      phoneError = 'Phone number must be 10 digits';
      isValid = false;
    } else {
      phoneError = null;
    }

    if (aadhaarController.text.trim().isEmpty) {
      aadhaarError = 'Aadhaar number is required';
      isValid = false;
    } else if (!RegExp(
      r'^[0-9]{12}$',
    ).hasMatch(aadhaarController.text.trim())) {
      aadhaarError = 'Aadhaar must be 12 digits';
      isValid = false;
    } else {
      aadhaarError = null;
    }

    if (dobController.text.isEmpty) {
      dobError = 'Date of Birth is required';
      isValid = false;
    } else {
      dobError = null;
    }

    if (addressController.text.trim().isEmpty) {
      addressError = 'Address is required';
      isValid = false;
    } else {
      addressError = null;
    }

    return isValid;
  }

  EditWorkerModel getEditedWorker() {
    return EditWorkerModel(
      name: nameController.text.trim(),
      phone: phoneNumber!,
      aadhaar: aadhaarController.text.trim(),
      dob: dobController.text.trim(),
      address: addressController.text.trim(),
    );
  }

  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    aadhaarController.dispose();
    dobController.dispose();
    addressController.dispose();
  }
}
