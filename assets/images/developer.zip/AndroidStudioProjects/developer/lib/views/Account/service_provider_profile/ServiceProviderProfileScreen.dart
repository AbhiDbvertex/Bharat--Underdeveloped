// SellerScreen.dart
import 'dart:convert';
import 'dart:io';

import 'package:developer/views/Account/service_provider_profile/EditProfileScreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Widgets/AppColors.dart';
import '../../../models/ServiceProviderModel/ServiceProviderProfileModel.dart';
import '../../ServiceProvider/WorkerScreen.dart';
import 'HisWorkScreen.dart';
import 'ReviewImagesScreen.dart';

// ignore_for_file: use_build_context_synchronously

class SellerScreen extends StatefulWidget {
  const SellerScreen({super.key});

  @override
  State<SellerScreen> createState() => _SellerScreenState();
}

class _SellerScreenState extends State<SellerScreen> {
  File? _pickedImage;
  ServiceProviderProfileModel? profile;
  bool isLoading = true;
  bool _showReviews = true;

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  Future<void> _pickImageFromCamera() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
    ); // Or .camera if needed

    if (pickedFile != null) {
      setState(() {
        _pickedImage = File(pickedFile.path);
      });

      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');

      if (token == null || token.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("🔐 Token not found. Please login again."),
          ),
        );
        return;
      }

      final url = Uri.parse(
        "https://api.thebharatworks.com/api/user/updateProfilePic",
      );

      try {
        var request =
            http.MultipartRequest("PUT", url)
              ..headers['Authorization'] = 'Bearer $token'
              ..files.add(
                await http.MultipartFile.fromPath(
                  'profilePic',
                  pickedFile.path,
                ),
              );

        final response = await request.send();

        if (response.statusCode == 200) {
          final responseData = await response.stream.bytesToString();
          final jsonData = jsonDecode(responseData);

          debugPrint("✅ Response: $jsonData");

          if (jsonData['profilePic'] != null) {
            setState(() {
              profile?.profilePic = jsonData['profilePic'];
              profile?.fullName = jsonData['full_name']; // optional
            });

            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("✅ Profile picture updated")),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(jsonData['message'] ?? "❌ Upload failed")),
            );
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("❌ Upload failed! Try again.")),
          );
        }
      } catch (e) {
        debugPrint("Upload error: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("⚠️ Something went wrong!")),
        );
      }
    }
  }

  Future<void> fetchProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token') ?? '';
      final url = Uri.parse(
        "https://api.thebharatworks.com/api/user/getUserProfileData",
      );

      final response = await http.get(
        url,
        headers: {HttpHeaders.authorizationHeader: 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true) {
          setState(() {
            profile = ServiceProviderProfileModel.fromJson(data['data']);
            isLoading = false;
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data["message"] ?? "Profile fetch failed")),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Server error, profile fetch failed!")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Something went wrong, try again!")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child:
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildHeader(context),
                      Column(
                        mainAxisSize:
                            MainAxisSize
                                .min, // prevent unnecessary vertical expansion
                        children: [
                          Stack(
                            clipBehavior: Clip.none,
                            children: [
                              CircleAvatar(
                                radius: 50,
                                backgroundColor: Colors.grey.shade300,
                                backgroundImage:
                                    _pickedImage != null
                                        ? FileImage(_pickedImage!)
                                        : (profile?.profilePic != null
                                                ? NetworkImage(
                                                  profile!.profilePic!,
                                                )
                                                : null)
                                            as ImageProvider?,
                                child:
                                    _pickedImage == null &&
                                            profile?.profilePic == null
                                        ? const Icon(
                                          Icons.person,
                                          size: 50,
                                          color: Colors.white,
                                        )
                                        : null,
                              ),
                              Positioned(
                                bottom: 4,
                                right: 4,
                                child: InkWell(
                                  onTap: _pickImageFromCamera,
                                  child: const Icon(
                                    Icons.camera_alt,
                                    size: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          Text(
                            profile?.fullName ?? '',
                            style: GoogleFonts.roboto(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.location_on,
                                color: Colors.green.shade700,
                                size: 16,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                profile?.currentLocation ?? '',
                                style: GoogleFonts.roboto(
                                  fontSize: 12,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              GestureDetector(
                                onTap: () async {
                                  final result = await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder:
                                          (context) =>
                                              const EditProfileScreen(),
                                    ),
                                  );
                                  if (result == true) {
                                    fetchProfile();
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text("✅ Profile updated"),
                                      ),
                                    );
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  width: 32, // smaller width
                                  height: 32, // smaller height
                                  child: Image.asset(
                                    'assets/images/edit1.png',
                                    height: 18,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "${profile?.totalReview ?? 0} Reviews",
                                style: GoogleFonts.roboto(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Row(
                                children: [
                                  Text(
                                    '(${profile?.rating ?? 0.0} ',
                                    style: GoogleFonts.roboto(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                    size: 14,
                                  ),
                                  Text(
                                    ')',
                                    style: GoogleFonts.roboto(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),

                      _buildProfileCard(),
                      const SizedBox(height: 16),
                      _buildHisWorkSection(),
                      const SizedBox(height: 12),
                      const SizedBox(height: 10),
                      _buildDocumentCard(),
                      const SizedBox(height: 12),
                      _buildAddAsapPersonTile(context),
                      const SizedBox(height: 12),
                      _buildCustomerReviews(),
                    ],
                  ),
                ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return ClipPath(
      clipper: BottomCurveClipper(),
      child: Container(
        color: const Color(0xFF9DF89D),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        height: 140,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: const Padding(
                    padding: EdgeInsets.only(left: 8.0),
                    child: Icon(Icons.arrow_back, size: 25),
                  ),
                ),
                const SizedBox(width: 100),
                Text(
                  "Profile",
                  style: GoogleFonts.roboto(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
            Center(child: _buildRoleSwitcher(context)),
          ],
        ),
      ),
    );
  }

  Widget _buildRoleSwitcher(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            "User",
            style: GoogleFonts.poppins(
              fontSize: 12,
              color: Colors.green.shade800,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.green.shade800,
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Text(
            "Worker",
            style: TextStyle(fontSize: 12, color: Colors.white),
          ),
        ),
      ],
    );
  }

  Widget _buildProfileCard() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.all(1),
      decoration: BoxDecoration(
        color: const Color(0xFF9DF89D),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Text(
                    "Category: ${profile?.categoryName ?? 'N/A'}",
                    style: GoogleFonts.poppins(
                      fontSize: 11,
                      color: Colors.green.shade800,
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 18.0),
                    child: Text(
                      "Sub-Category: ${profile?.subCategoryNames?.join(', ') ?? 'N/A'}",
                      style: GoogleFonts.poppins(fontSize: 11),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),
          _buildEmergencyCard(),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xffeaffea),
              borderRadius: const BorderRadius.vertical(
                bottom: Radius.circular(14),
              ),
            ),
            child: Column(
              children: [
                Image.asset(
                  "assets/images/task.png",
                  height: 160,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _buildTabButtons(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmergencyCard() {
    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.shade200),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: Colors.red),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "Emergency task.",
              style: GoogleFonts.roboto(fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHisWorkSection() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "About My Skill",
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(profile?.skill ?? ''),
        ],
      ),
    );
  }

  Widget _buildDocumentCard() {
    return Container(
      height: 160,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 5),
          Text(
            "Document",
            style: GoogleFonts.roboto(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              Image.asset('assets/images/line2.png', height: 24),
              const SizedBox(width: 20),
              Text(
                "Aadhar card",
                style: GoogleFonts.roboto(
                  fontWeight: FontWeight.w400,
                  fontSize: 14,
                ),
              ),
              const SizedBox(width: 50),
              if (profile?.documents != null && profile!.documents!.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: Image.network(
                    profile!.documents!,
                    height: 80,
                    width: 80,
                    fit: BoxFit.cover,
                    errorBuilder:
                        (_, __, ___) => const Icon(Icons.broken_image),
                  ),
                )
              else
                Text(
                  "(Not uploaded)",
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontStyle: FontStyle.italic,
                    fontSize: 12,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAddAsapPersonTile(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Image.asset('assets/images/contact.png'),
        title: Text("Assign Person", style: GoogleFonts.roboto(fontSize: 13)),
        trailing: const Icon(Icons.arrow_forward, size: 20),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const WorkerScreen()),
          );
        },
      ),
    );
  }

  Widget _buildTabButtons() {
    return Row(
      children: [
        _tabButton("His Work", _showReviews, () {
          setState(() => _showReviews = true);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (context) => HisWorkScreen(images: profile?.hisWork ?? []),
            ),
          );
        }),
        const SizedBox(width: 10),
        _tabButton("User Review", !_showReviews, () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (context) =>
                      ReviewImagesScreen(images: profile?.customerReview ?? []),
            ),
          );
        }),
      ],
    );
  }

  Widget _tabButton(String title, bool selected, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 35,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFFC3FBD8),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: Text(
            title,
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w300,
              color: Colors.green.shade800,
            ),
          ),
        ),
      ),
    );
  }

  // Add this helper function anywhere in your file (e.g. below _buildCustomerReviews)

  Widget buildStarRating(double rating) {
    List<Widget> stars = [];
    int fullStars = rating.floor();
    bool hasHalfStar = (rating - fullStars) >= 0.5;

    for (int i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.add(const Icon(Icons.star, color: Colors.orange, size: 18));
      } else if (i == fullStars && hasHalfStar) {
        stars.add(const Icon(Icons.star_half, color: Colors.orange, size: 18));
      } else {
        stars.add(
          const Icon(Icons.star_border, color: Colors.orange, size: 18),
        );
      }
    }

    return Row(children: stars);
  }

  Widget _buildCustomerReviews() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Rate & Reviews",
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          if (_showReviews)
            if (profile?.rateAndReviews?.isNotEmpty ?? false)
              ...profile!.rateAndReviews!.map(
                (r) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        buildStarRating(r.rating ?? 0),
                        const SizedBox(width: 6),
                        Text(
                          "(${r.rating?.toStringAsFixed(1)})",
                          style: const TextStyle(fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(r.review ?? ''),
                    const SizedBox(height: 6),
                    if ((r.images ?? []).isNotEmpty)
                      Wrap(
                        spacing: 8,
                        children:
                            (r.images ?? [])
                                .map(
                                  (img) => ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      img,
                                      width: 50,
                                      height: 50,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                )
                                .toList(),
                      ),
                    const Divider(),
                  ],
                ),
              )
            else
              const Text("No reviews available.")
          else
            const Text("No customer review images available."),
        ],
      ),
    );
  }
}

class BottomCurveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    return Path()
      ..lineTo(0, size.height - 40)
      ..quadraticBezierTo(
        size.width / 2,
        size.height,
        size.width,
        size.height - 30,
      )
      ..lineTo(size.width, 0)
      ..close();
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
