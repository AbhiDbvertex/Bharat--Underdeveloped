import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'PaymentSuccessScreen.dart';

class RazorpayScreen extends StatefulWidget {
  final String razorpayOrderId;
  final int amount; // e.g. ₹250 = 25000
  final categreyId;
  final subcategreyId;

  const RazorpayScreen({
    super.key,
    required this.razorpayOrderId,
    required this.amount,
    this.categreyId,
    this.subcategreyId,
  });

  @override
  State<RazorpayScreen> createState() => _RazorpayScreenState();
}

class _RazorpayScreenState extends State<RazorpayScreen> {
  late Razorpay _razorpay;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handleSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handleError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    _openCheckout();
  }

  void _openCheckout() {
    var options = {
      'key': 'rzp_test_0MfRVH2Hq6cqgy',
      'amount': widget.amount,
      'name': 'The Bharat Works',
      'description': 'Platform Fee',
      'order_id': widget.razorpayOrderId,
      'prefill': {'contact': '9876543210', 'email': 'example@email.com'},
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('🛑 Razorpay open error: $e');
    }
  }

  void _handleSuccess(PaymentSuccessResponse response) async {
    print("✅ Payment Success:");
    print("Order ID: ${widget.razorpayOrderId}");
    print("Payment ID: ${response.paymentId}");
    print("Signature: ${response.signature}");

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');

      if (token == null) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("❌ User not logged in")));
        return;
      }

      final res = await http.post(
        Uri.parse(
          'https://api.thebharatworks.com/api/direct-order/verify-platform-payment',
        ),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          "razorpay_order_id": widget.razorpayOrderId,
          "razorpay_payment_id": response.paymentId,
          "razorpay_signature": response.signature,
        }),
      );

      final decoded = jsonDecode(res.body);
      print("📦 Verify API response: $decoded");

      if (res.statusCode == 200) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder:
                (context) => PaymentSuccessScreen(
                  categreyId: widget.categreyId,
                  subcategreyId: widget.subcategreyId,
                ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("❌ Verification Failed: ${decoded['message']}"),
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      print("❌ Verification Error: $e");
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Error verifying payment")));
      Navigator.pop(context);
    }
  }

  void _handleError(PaymentFailureResponse response) {
    print("❌ Payment Failed: ${response.message}");
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("❌ Payment Failed")));
    Navigator.pop(context);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    print("📲 External Wallet: ${response.walletName}");
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("Wallet: ${response.walletName}")));
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print(
      "Abhi:- razorpay screen get categreyId ${widget.categreyId} : subCategreyId : ${widget.subcategreyId}",
    );
    return const Scaffold(
      body: Center(
        child: Text("🔁 Opening Razorpay...", style: TextStyle(fontSize: 18)),
      ),
    );
  }
}
