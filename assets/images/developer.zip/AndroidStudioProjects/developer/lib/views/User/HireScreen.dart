import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Consent/ApiEndpoint.dart';
import '../../Consent/app_constants.dart';
import '../../Widgets/AppColors.dart';
import '../Account/RazorpayScreen.dart';

class HireScreen extends StatefulWidget {
  final categreyId;
  final subcategreyId;
  final String firstProviderId;

  const HireScreen({
    super.key,
    required this.firstProviderId,
    this.categreyId,
    this.subcategreyId,
  });

  @override
  State<HireScreen> createState() => _HireScreenState();
}

class _HireScreenState extends State<HireScreen> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final addressController = TextEditingController();

  DateTime? selectedDate;
  File? selectedImage;

  Future<void> pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => selectedDate = picked);
    }
  }

  Future<void> pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => selectedImage = File(picked.path));
    }
  }

  Future<bool> showConfirmationDialog() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (context) {
            return AlertDialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              contentPadding: const EdgeInsets.all(20),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    'assets/images/success.png',
                    height: 120,
                    width: 120,
                    fit: BoxFit.cover,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "Are you Sure want to hire?",
                    style: GoogleFonts.roboto(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green.shade700,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          onPressed: () => Navigator.pop(context, true),
                          child: Text(
                            "Okay",
                            style: GoogleFonts.roboto(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            side: BorderSide(color: Colors.green.shade700),
                          ),
                          onPressed: () => Navigator.pop(context, false),
                          child: Text(
                            "Cancel",
                            style: GoogleFonts.roboto(
                              fontWeight: FontWeight.bold,
                              color: Colors.green.shade700,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ) ??
        false;
  }

  Future<void> submitForm() async {
    final confirmed = await showConfirmationDialog();
    if (!mounted || !confirmed) return;

    final title = titleController.text.trim();
    final description = descriptionController.text.trim();
    final address = addressController.text.trim();

    if (title.isEmpty ||
        description.isEmpty ||
        address.isEmpty ||
        selectedDate == null ||
        selectedImage == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Please fill all fields')));
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('User not logged in')));
      return;
    }

    final request = http.MultipartRequest(
      'POST',
      Uri.parse('${AppConstants.baseUrl}${ApiEndpoint.hireScreen}'),
    );

    request.headers['Authorization'] = 'Bearer $token';
    request.fields['first_provider_id'] = widget.firstProviderId;
    request.fields['title'] = title;
    request.fields['description'] = description;
    request.fields['address'] = address;
    request.fields['deadline'] = selectedDate!.toIso8601String();

    request.files.add(
      await http.MultipartFile.fromPath(
        'image',
        selectedImage!.path,
        filename: p.basename(selectedImage!.path),
      ),
    );

    try {
      final response = await request.send();
      final respStr = await response.stream.bytesToString();

      if (!mounted) return;

      if (response.statusCode == 201) {
        final decoded = jsonDecode(respStr);
        final razorpayOrderId = decoded['razorpay_order']['id'];
        final amount = decoded['razorpay_order']['amount'];

        final paymentSuccess = await Navigator.push(
          context,
          MaterialPageRoute(
            builder:
                (context) => RazorpayScreen(
                  razorpayOrderId: razorpayOrderId,
                  amount: amount,
                  categreyId: widget.categreyId,
                  subcategreyId: widget.subcategreyId,
                ),
          ),
        );

        if (!mounted) return;

        if (paymentSuccess == true) {
          List<String> hiredProviders =
              prefs.getStringList('hiredProviders') ?? [];
          if (!hiredProviders.contains(widget.firstProviderId)) {
            hiredProviders.add(widget.firstProviderId);
            await prefs.setStringList('hiredProviders', hiredProviders);
          }

          if (!mounted) return;
          Navigator.pop(context, widget.firstProviderId);
        }
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('❌ Failed: $respStr')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(
                      Icons.arrow_back_outlined,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(width: 86),
                  Text(
                    "Direct hire",
                    style: GoogleFonts.roboto(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              buildLabel("Title"),
              const SizedBox(height: 6),
              buildTextField("Enter Title of work", titleController),
              const SizedBox(height: 14),
              buildLabel("Platform Fees"),
              const SizedBox(height: 6),
              buildPlatformFeeField(),
              const SizedBox(height: 14),
              buildLabel("Description"),
              const SizedBox(height: 6),
              buildDescriptionField(),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  buildLabel("Address"),
                  const Text(
                    "Edit",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              buildAddressField(),
              const SizedBox(height: 14),
              buildLabel("Add deadline and time"),
              const SizedBox(height: 6),
              buildDatePicker(),
              const SizedBox(height: 14),
              buildLabel("Upload"),
              const SizedBox(height: 6),
              buildImageUpload(),
              const SizedBox(height: 24),
              Center(
                child: SizedBox(
                  width: 200,
                  child: ElevatedButton(
                    onPressed: submitForm,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      "Hire",
                      style: GoogleFonts.roboto(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildLabel(String label) {
    return Text(
      label,
      style: GoogleFonts.roboto(
        fontSize: 15,
        fontWeight: FontWeight.w500,
        color: Colors.black87,
      ),
    );
  }

  Widget buildTextField(String hint, TextEditingController controller) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.grey[100],
      ),
    );
  }

  Widget buildPlatformFeeField() {
    return TextField(
      enabled: false,
      decoration: InputDecoration(
        hintText: "Rs 200.00",
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.grey[100],
      ),
    );
  }

  Widget buildDescriptionField() {
    return TextField(
      controller: descriptionController,
      maxLines: 4,
      decoration: InputDecoration(
        hintText: "Write description...",
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.grey[100],
      ),
    );
  }

  Widget buildAddressField() {
    return TextField(
      controller: addressController,
      decoration: InputDecoration(
        hintText: "Enter Full Address",
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.grey[100],
        suffixIcon: IconButton(
          icon: const Icon(Icons.location_on, color: Colors.green),
          onPressed: () {
            print("📍 Location picker tapped");
          },
        ),
      ),
    );
  }

  Widget buildDatePicker() {
    return TextField(
      readOnly: true,
      onTap: pickDate,
      decoration: InputDecoration(
        hintText:
            selectedDate == null
                ? "Select date"
                : "${selectedDate!.day.toString().padLeft(2, '0')}-${selectedDate!.month.toString().padLeft(2, '0')}-${selectedDate!.year}",
        prefixIcon: const Icon(Icons.calendar_today),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.grey[100],
      ),
    );
  }

  Widget buildImageUpload() {
    return GestureDetector(
      onTap: pickImage,
      child: Container(
        height: 100,
        width: double.infinity,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade400),
          borderRadius: BorderRadius.circular(10),
        ),
        child:
            selectedImage == null
                ? const Center(
                  child: Text(
                    "Upload Image",
                    style: TextStyle(color: Colors.green),
                  ),
                )
                : ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.file(selectedImage!, fit: BoxFit.cover),
                ),
      ),
    );
  }
}
