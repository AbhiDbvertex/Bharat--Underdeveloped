import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/AppColors.dart';
import '../../models/userModel/subCategoriesModel.dart';
import 'HireScreen.dart';
import 'UserViewWorkerDetails.dart';

class WorkerlistScreen extends StatefulWidget {
  final dynamic categreyId;
  final dynamic subcategreyId;
  final List<ServiceProviderModel> providers;

  const WorkerlistScreen({
    Key? key,
    required this.providers,
    this.categreyId,
    this.subcategreyId,
  }) : super(key: key);

  @override
  State<WorkerlistScreen> createState() => _WorkerlistScreenState();
}

class _WorkerlistScreenState extends State<WorkerlistScreen> {
  late List<ServiceProviderModel> providerslist;

  @override
  void initState() {
    super.initState();
    providerslist = List.from(widget.providers);
  }

  String? getImageUrl(ServiceProviderModel worker) {
    if (worker.hisWork.isNotEmpty) {
      final path = worker.hisWork.first.replaceAll("\\", "/");
      return "https://api.thebharatworks.com/$path";
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 10,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                  child: const Icon(Icons.arrow_back_outlined, size: 22),
                ),
                const SizedBox(width: 90),
                Text(
                  "Direct hire",
                  style: GoogleFonts.roboto(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.only(right: 12.0),
                  child: Image.asset('assets/images/filter.png'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 50,
            width: 320,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.grey.shade200,
            ),
            child: Row(
              children: [
                const SizedBox(width: 8),
                Image.asset('assets/images/search1.png', height: 20, width: 20),
                const SizedBox(width: 15),
                Text(
                  "Search for services",
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    color: const Color(0xFF616161),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child:
                providerslist.isEmpty
                    ? Center(
                      child: Text(
                        "No Worker Available",
                        style: GoogleFonts.roboto(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: Colors.grey,
                        ),
                      ),
                    )
                    : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      itemCount: providerslist.length,
                      itemBuilder: (context, index) {
                        final worker = providerslist[index];
                        final imageUrl = getImageUrl(worker);

                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.1),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child:
                                    imageUrl != null
                                        ? Image.network(
                                          imageUrl,
                                          height: 100,
                                          width: 100,
                                          fit: BoxFit.cover,
                                          errorBuilder:
                                              (context, error, stackTrace) =>
                                                  const Icon(
                                                    Icons.broken_image,
                                                    size: 40,
                                                  ),
                                        )
                                        : Image.asset(
                                          "assets/images/account1.png",
                                          height: 100,
                                          width: 100,
                                          fit: BoxFit.cover,
                                        ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 10),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: Text(
                                            worker.fullName ?? "Unknown",
                                            style: GoogleFonts.roboto(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              worker.rating.toStringAsFixed(1),
                                              style: GoogleFonts.roboto(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                            const Icon(
                                              Icons.star,
                                              size: 18,
                                              color: Colors.yellow,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    Text(
                                      "\u20B9200.00",
                                      style: GoogleFonts.roboto(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.grey[700],
                                        fontSize: 13,
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            worker.skill ?? "No skill info",
                                            style: GoogleFonts.roboto(
                                              fontSize: 11,
                                              color: Colors.grey[700],
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            if (worker.id != null &&
                                                worker.id!.isNotEmpty) {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder:
                                                      (_) =>
                                                          UserViewWorkerDetails(
                                                            workerId:
                                                                worker.id!,
                                                          ),
                                                ),
                                              );
                                            }
                                          },
                                          child: Text(
                                            "View Profile",
                                            style: GoogleFonts.roboto(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.green.shade700,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 6),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 35,
                                            vertical: 4,
                                          ),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFF27773),
                                            borderRadius: BorderRadius.circular(
                                              20,
                                            ),
                                          ),
                                          child: Text(
                                            worker.location ?? "No location",
                                            style: GoogleFonts.roboto(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                        ElevatedButton(
                                          onPressed: () async {
                                            final hiredId = await Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder:
                                                    (_) => HireScreen(
                                                      firstProviderId:
                                                          worker.id ?? '',
                                                      categreyId:
                                                          widget.categreyId,
                                                      subcategreyId:
                                                          widget.subcategreyId,
                                                    ),
                                              ),
                                            );
                                            if (hiredId != null) {
                                              final prefs =
                                                  await SharedPreferences.getInstance();
                                              List<String> hiredProviders =
                                                  prefs.getStringList(
                                                    'hiredProviders',
                                                  ) ??
                                                  [];
                                              if (!hiredProviders.contains(
                                                hiredId,
                                              )) {
                                                hiredProviders.add(hiredId);
                                                await prefs.setStringList(
                                                  'hiredProviders',
                                                  hiredProviders,
                                                );
                                              }
                                              setState(() {
                                                providerslist.removeWhere(
                                                  (e) => e.id == hiredId,
                                                );
                                              });
                                            }
                                          },
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                Colors.green.shade700,
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 12,
                                              vertical: 4,
                                            ),
                                            minimumSize: const Size(60, 28),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                            ),
                                          ),
                                          child: Text(
                                            "Hire",
                                            style: GoogleFonts.roboto(
                                              fontSize: 12,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
          ),
        ],
      ),
    );
  }
}
