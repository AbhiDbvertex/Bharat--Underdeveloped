import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../Widgets/AppColors.dart';

class UserNotificationScreen extends StatelessWidget {
  const UserNotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: Column(
          children: [
            SizedBox(height: 10),

            Row(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: const Padding(
                    padding: EdgeInsets.only(left: 8.0),
                    child: Icon(Icons.arrow_back, size: 25),
                  ),
                ),
                const SizedBox(width: 90),
                Text(
                  "Notification",
                  style: GoogleFonts.roboto(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ],
            ),

            SizedBox(height: 150),
            Image.asset(
              'assets/images/notification.png', // <-- replace with your actual image path
              height: 250,
            ),
            const SizedBox(height: 20),
            Text(
              'No Notification Available',
              style: GoogleFonts.roboto(color: Colors.grey, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}
