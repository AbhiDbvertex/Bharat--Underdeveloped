import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Consent/ApiEndpoint.dart';
import '../../Consent/app_constants.dart';
import '../../Widgets/AppColors.dart';
import '../../models/ServiceProviderModel/DirectOrder.dart';
import 'DirecrViewScreen.dart';

class MyHireScreen extends StatefulWidget {
  final String? categreyId;
  final String? subcategreyId;

  const MyHireScreen({super.key, this.categreyId, this.subcategreyId});

  @override
  State<MyHireScreen> createState() => _MyHireScreenState();
}

class _MyHireScreenState extends State<MyHireScreen> {
  bool isLoading = false;
  List<DirectOrder> orders = [];

  String? categoryId;
  String? subCategoryId;

  int selectedTab = 1; // 0 = Bidding, 1 = Direct Hiring, 2 = Emergency

  @override
  void initState() {
    super.initState();
    _loadCategoryIdsAndFetchOrders();
  }

  Future<void> _loadCategoryIdsAndFetchOrders() async {
    final prefs = await SharedPreferences.getInstance();

    categoryId = widget.categreyId ?? prefs.getString('category_id') ?? '1';
    subCategoryId =
        widget.subcategreyId ?? prefs.getString('sub_category_id') ?? '10';

    print("✅ MyHireScreen using categoryId: $categoryId");
    print("✅ MyHireScreen using subCategoryId: $subCategoryId");

    fetchDirectOrders();
  }

  Future<void> fetchDirectOrders() async {
    setState(() => isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token') ?? '';

      final res = await http.get(
        Uri.parse('${AppConstants.baseUrl}${ApiEndpoint.MyHireScreen}'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      print("🔁 API Response: ${res.body}");

      if (res.statusCode == 200) {
        final decoded = json.decode(res.body);
        final List<dynamic> data = decoded['data'];

        setState(() {
          orders = data.map((e) => DirectOrder.fromJson(e)).toList();
        });
      } else {
        print("❌ API Error Status: ${res.statusCode}");
      }
    } catch (e) {
      print("❌ API Exception: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'cancelled':
        return Colors.red;
      case 'accepted':
        return Colors.green;
      case 'completed':
        return Colors.brown;
      case 'pending':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Center(
              child: Text(
                "My Hire",
                style: GoogleFonts.roboto(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),

          /// Tabs
          Container(
            width: double.infinity,
            height: 50,
            color: Colors.green.shade100,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildTabButton("Bidding Tasks", 0),
                _verticalDivider(),
                _buildTabButton("Direct Hiring", 1),
                _verticalDivider(),
                _buildTabButton("Emergency Tasks", 2),
              ],
            ),
          ),
          const SizedBox(height: 12),

          /// Content
          Expanded(
            child: Builder(
              builder: (_) {
                if (isLoading) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (selectedTab == 0) {
                  return const Center(child: Text("No Bidding Tasks Found"));
                } else if (selectedTab == 1) {
                  return _buildDirectHiringList();
                } else {
                  return const Center(child: Text("No Emergency Tasks Found"));
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  /// Tab UI Builder
  Widget _buildTabButton(String title, int tabIndex) {
    final isSelected = selectedTab == tabIndex;
    return ElevatedButton(
      onPressed: () {
        setState(() {
          selectedTab = tabIndex;
        });
      },
      style: ElevatedButton.styleFrom(
        backgroundColor:
            isSelected ? Colors.green.shade700 : Colors.green.shade100,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      child: Text(
        title,
        style: _tabText(color: isSelected ? Colors.white : Colors.black),
      ),
    );
  }

  Widget _verticalDivider() {
    return Container(width: 1, height: 40, color: Colors.white38);
  }

  Widget _buildDirectHiringList() {
    if (orders.isEmpty) {
      return const Center(child: Text("No Direct Hiring Found"));
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, index) => _buildHireCard(orders[index]),
      ),
    );
  }

  Widget _buildHireCard(DirectOrder data) {
    final bool isNetworkImage = data.image != 'local';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child:
                isNetworkImage
                    ? Image.network(
                      data.image,
                      height: 110,
                      width: 110,
                      fit: BoxFit.cover,
                      errorBuilder:
                          (context, error, stackTrace) => Image.asset(
                            'assets/images/task.png',
                            height: 110,
                            width: 110,
                            fit: BoxFit.cover,
                          ),
                    )
                    : Image.asset(
                      'assets/images/task.png',
                      height: 110,
                      width: 110,
                      fit: BoxFit.cover,
                    ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data.title,
                  style: _cardTitle(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  data.description,
                  style: _cardBody(),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text("Posted Date: ${data.date}", style: _cardDate()),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: _getStatusColor(data.status),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        data.status,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) => DirectViewScreen(
                                  id: data.id,
                                  categreyId: categoryId,
                                  subcategreyId: subCategoryId,
                                ),
                          ),
                        );
                      },
                      style: TextButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        minimumSize: const Size(90, 36),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      child: Text(
                        "View Details",
                        style: GoogleFonts.roboto(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  TextStyle _tabText({Color color = Colors.black}) => GoogleFonts.roboto(
    color: color,
    fontWeight: FontWeight.w500,
    fontSize: 12,
  );

  TextStyle _cardTitle() =>
      GoogleFonts.roboto(fontSize: 15, fontWeight: FontWeight.bold);
  TextStyle _cardBody() => GoogleFonts.roboto(fontSize: 13);
  TextStyle _cardDate() =>
      GoogleFonts.roboto(fontSize: 12, color: Colors.grey[700]);
}
