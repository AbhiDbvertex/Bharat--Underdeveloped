import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/AppColors.dart';
import '../../Widgets/Bottombar.dart';
import '../../Widgets/CustomButton.dart';
import '../../controllers/authController/UserDetailsController.dart';
import '../../models/RoleModel.dart';
import 'MapPickerScreen.dart';

class UserDetailFormScreen extends StatefulWidget {
  final String role;

  const UserDetailFormScreen({super.key, required this.role});

  @override
  State<UserDetailFormScreen> createState() => _UserDetailFormScreenState();
}

class _UserDetailFormScreenState extends State<UserDetailFormScreen> {
  late final RoleModel model;
  late final UserDetailsController controller;

  @override
  void initState() {
    super.initState();
    model = RoleModel();
    controller = UserDetailsController();
    controller.setRole(widget.role);
    model.selectedRole = widget.role;
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  InputDecoration getInputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(fontSize: 12, color: Color(0xFF7B7B7B)),
      filled: true,
      fillColor: AppColors.white,
      contentPadding: const EdgeInsets.symmetric(vertical: 17, horizontal: 12),
      enabledBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: AppColors.greyBorder, width: 1.5),
        borderRadius: BorderRadius.circular(15),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: AppColors.greyBorder, width: 1.5),
        borderRadius: BorderRadius.circular(15),
      ),
    );
  }

  Widget buildCustomField({
    required String fieldKey,
    required TextEditingController controllerField,
    required String hint,
    List<TextInputFormatter>? formatters,
    bool readOnly = false,
    VoidCallback? onTap,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 50,
          child: TextFormField(
            controller: controllerField,
            textAlign: TextAlign.center,
            inputFormatters: formatters,
            readOnly: readOnly,
            onTap: onTap,
            decoration: getInputDecoration(hint),
            style: const TextStyle(fontSize: 13),
          ),
        ),
        if (controller.errorTexts[fieldKey] != null)
          Padding(
            padding: const EdgeInsets.only(top: 5, bottom: 10),
            child: SizedBox(
              width: double.infinity,
              child: Text(
                controller.errorTexts[fieldKey]!,
                style: const TextStyle(color: AppColors.red, fontSize: 12),
                textAlign: TextAlign.center,
              ),
            ),
          )
        else
          const SizedBox(height: 25),
      ],
    );
  }

  Future<void> _openMapPicker() async {
    final selectedAddress = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => MapPickerScreen()),
    );

    if (selectedAddress != null) {
      setState(() {
        controller.currentLocationController.text = selectedAddress;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Location Selected: $selectedAddress")),
      );
    }
  }

  Future<void> _fillFullAddressFromLocation() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Location permission denied")),
          );
          return;
        }
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty) {
        final place = placemarks.first;
        final address =
            "${place.street ?? ''}, ${place.subLocality ?? ''}, ${place.locality ?? ''}, ${place.administrativeArea ?? ''}, ${place.country ?? ''}";

        setState(() {
          controller.fullAddressController.text = address.trim();
        });

        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Address fetched: $address")));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("No address found for this location")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Failed to fetch location: $e")));
    }
  }

  Widget buildLabel(String label) {
    return Center(
      child: Text(
        label,
        style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }

  Future<void> onSubmit() async {
    FocusScope.of(context).unfocus();

    final isValid = controller.validateForm(context);
    if (!isValid) {
      setState(() {});
      return;
    }

    final isSuccess = await controller.submitUserProfile(context);

    if (isSuccess) {
      // ✅ Save role in SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('role', controller.roleController.text);

      // ✅ Debug print
      print("📝 Role Saved: ${controller.roleController.text}");

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => Bottombar() /*UserHomeScreen()*/),
      );
    } else {
      debugPrint("Submission failed");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: AppColors.green,
        elevation: 0,
        toolbarHeight: 10,
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.arrow_back_outlined, size: 22),
                  ),
                  const SizedBox(width: 60),
                  Text(
                    'Complete Profile',
                    style: GoogleFonts.poppins(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 50),

              buildLabel("What's your Name?"),
              const SizedBox(height: 5),
              buildCustomField(
                fieldKey: 'name',
                controllerField: controller.nameController,
                hint: 'Enter Your Name',
                formatters: [
                  FilteringTextInputFormatter.allow(RegExp(r"[a-zA-Z\s'-]+")),
                ],
              ),

              buildLabel('House Number'),
              const SizedBox(height: 5),
              buildCustomField(
                fieldKey: 'houseNumber',
                controllerField: controller.houseNumberController,
                hint: 'Enter Your house Number',
              ),

              buildLabel('Colony Name'),
              const SizedBox(height: 5),
              buildCustomField(
                fieldKey: 'colonyName',
                controllerField: controller.colonyNameController,
                hint: 'Enter Your Colony Name',
              ),

              buildLabel('Landmark'),
              const SizedBox(height: 5),
              buildCustomField(
                fieldKey: 'landmark',
                controllerField: controller.landmarkController,
                hint: 'Enter Your Landmark',
              ),

              buildLabel('Location(GPS)'),
              const SizedBox(height: 5),
              buildCustomField(
                fieldKey: 'location',
                controllerField: controller.locationController,
                hint: 'Enter Your Location',
              ),

              buildLabel('Current Location (Map)'),
              const SizedBox(height: 5),
              buildCustomField(
                fieldKey: 'currentLocation',
                controllerField: controller.currentLocationController,
                hint: 'Select Location from Map',
                readOnly: true,
                onTap: _openMapPicker,
              ),

              buildLabel('Full Address(Landmark)'),
              const SizedBox(height: 5),
              SizedBox(
                height: 50,
                child: TextFormField(
                  controller: controller.fullAddressController,
                  textAlign: TextAlign.center,
                  decoration: getInputDecoration(
                    'Enter Your Full Address',
                  ).copyWith(
                    suffixIcon: IconButton(
                      icon: const Icon(
                        Icons.my_location,
                        color: AppColors.green,
                      ),
                      onPressed: _fillFullAddressFromLocation,
                    ),
                  ),
                  style: const TextStyle(fontSize: 13),
                ),
              ),
              if (controller.errorTexts['fullAddress'] != null)
                Padding(
                  padding: const EdgeInsets.only(top: 5, bottom: 10),
                  child: SizedBox(
                    width: double.infinity,
                    child: Text(
                      controller.errorTexts['fullAddress']!,
                      style: const TextStyle(
                        color: AppColors.red,
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              else
                const SizedBox(height: 25),

              buildLabel('Referral Code (Optional)'),
              const SizedBox(height: 5),
              buildCustomField(
                fieldKey: 'referral',
                controllerField: controller.referralController,
                hint: 'Enter Your Referral Code',
              ),

              const SizedBox(height: 20),
              CustomButton(label: 'Submit', onPressed: onSubmit),
            ],
          ),
        ),
      ),
    );
  }
}
