import 'package:developer/Widgets/CustomButton.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/AppColors.dart';
import '../../Widgets/Bottombar.dart';
import 'UserDetailFormScreen.dart';

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({super.key});

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen> {
  String selectedRole = 'user'; // Default selected role

  // Map role label (UI) to actual backend values
  static const roleMap = {'User': 'user', 'Business': 'service_provider'};

  // ✅ Store selected role to SharedPreferences
  Future<void> _saveSelectedRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('role', role);
    print("🔐 Role saved to prefs: $role");
  }

  Widget buildRole(BuildContext context, String label, String asset) {
    final isSelected = selectedRole == roleMap[label];

    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedRole = roleMap[label]!;
          });
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Column(
            children: [
              const SizedBox(height: 30),
              Stack(
                children: [
                  Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color:
                            isSelected
                                ? AppColors.primaryGreen
                                : Colors.grey.shade400,
                        width: 4,
                      ),
                    ),
                    child: ClipOval(
                      child: Image.asset(asset, fit: BoxFit.cover),
                    ),
                  ),
                  if (isSelected)
                    Positioned(
                      bottom: 10,
                      right: 10,
                      child: Container(
                        width: 25,
                        height: 25,
                        decoration: const BoxDecoration(
                          color: AppColors.primaryGreen,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check,
                          size: 15,
                          color: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold,
                  color: isSelected ? AppColors.green : AppColors.black87,
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// ✅ Check if profile is already complete, then go to right screen
  Future<void> navigateToForm(BuildContext context) async {
    await _saveSelectedRole(selectedRole);

    final prefs = await SharedPreferences.getInstance();
    final isProfileComplete = prefs.getBool('isProfileComplete') ?? false;

    if (isProfileComplete) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => Bottombar() /*UserHomeScreen()*/),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => UserDetailFormScreen(role: selectedRole),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: AppColors.green,
        elevation: 0,
        centerTitle: true,
        toolbarHeight: 10,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 40),
            Text(
              'Select your Role',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  Text(
                    'Please choose whether you are a Worker or a',
                    style: GoogleFonts.roboto(
                      fontSize: 14,
                      color: Color(0xFF777777),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  Text(
                    'User to proceed',
                    style: GoogleFonts.roboto(
                      fontSize: 14,
                      color: AppColors.greyText,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              height: 260,
              color: AppColors.backgroundLight,
              child: Row(
                children: [
                  buildRole(context, 'User', 'assets/images/Customer.png'),
                  buildRole(context, 'Business', 'assets/images/Business.png'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            CustomButton(
              onPressed: () => navigateToForm(context),
              label: 'Continue',
            ),
          ],
        ),
      ),
    );
  }
}
