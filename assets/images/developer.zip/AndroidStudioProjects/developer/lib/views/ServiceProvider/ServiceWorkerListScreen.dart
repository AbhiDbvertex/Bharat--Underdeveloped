import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/AppColors.dart'; // Replace with your own AppColors file

// Model
class ServiceWorkerListModel {
  final String id;
  final String name;
  final String location;
  final String image;
  final String date;

  ServiceWorkerListModel({
    required this.id,
    required this.name,
    required this.location,
    required this.image,
    required this.date,
  });

  factory ServiceWorkerListModel.fromJson(Map<String, dynamic> json) {
    final rawImage = json['image'] ?? '';
    final fullImageUrl =
        rawImage.startsWith('/uploads/worker/')
            ? 'https://api.thebharatworks.com$rawImage'
            : 'https://api.thebharatworks.com/uploads/worker/default.jpg';

    return ServiceWorkerListModel(
      id: json['_id'] ?? '',
      name: json['name'] ?? '',
      location: json['address'] ?? 'Unknown',
      image: fullImageUrl,
      date: json['dob']?.split("T")[0] ?? '',
    );
  }
}

// Screen
class ServiceWorkerListScreen extends StatefulWidget {
  @override
  _ServiceWorkerListScreenState createState() =>
      _ServiceWorkerListScreenState();
}

class _ServiceWorkerListScreenState extends State<ServiceWorkerListScreen> {
  List<ServiceWorkerListModel> workers = [];
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    fetchWorkers();
  }

  Future<void> fetchWorkers() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';
    print("🟢 Token: $token");

    final url = Uri.parse("https://api.thebharatworks.com/api/worker/all");

    try {
      final response = await http.get(
        url,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
      );

      print("📥 Status: ${response.statusCode}");
      print("📥 Body: ${response.body}");

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List workerList = data['workers'];
        setState(() {
          workers =
              workerList
                  .map((e) => ServiceWorkerListModel.fromJson(e))
                  .toList();
          isLoading = false;
        });
      } else if (response.statusCode == 401) {
        final responseData = json.decode(response.body);
        if (responseData['expired'] == true) {
          await prefs.remove("auth_token");
          setState(() {
            errorMessage = "Session expired. Please login again.";
            isLoading = false;
          });
          Future.delayed(Duration(seconds: 2), () {
            Navigator.pushReplacementNamed(context, '/login');
          });
          return;
        }
      } else {
        setState(() {
          isLoading = false;
          errorMessage = json.decode(response.body)['message'];
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        errorMessage = 'Error: ${e.toString()}';
      });
    }
  }

  Future<void> assignOrderToWorker(String workerId) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';

    final url = Uri.parse(
      "https://api.thebharatworks.com/api/worker/assign-order",
    );

    final body = {
      "worker_id": workerId,
      "order_id":
          "685d2849b93a9a07a9fe3d84", // TODO: Replace with dynamic order ID if needed
      "type": "direct",
    };

    try {
      final response = await http.post(
        url,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
        body: jsonEncode(body),
      );

      print("📤 Assign Status: ${response.statusCode}");
      print("📤 Assign Body: ${response.body}");

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("✅ Worker assigned successfully!")),
        );
      } else {
        final data = json.decode(response.body);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("❌ ${data['message'] ?? 'Assignment failed'}"),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("❌ Error: ${e.toString()}")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                InkWell(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.arrow_back, color: Colors.black),
                ),
                SizedBox(width: 100),
                Text(
                  'Worker List',
                  style: GoogleFonts.roboto(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          // Worker List
          Expanded(
            child:
                isLoading
                    ? Center(child: CircularProgressIndicator())
                    : errorMessage != null
                    ? Center(child: Text(errorMessage!))
                    : ListView.builder(
                      padding: EdgeInsets.all(8.0),
                      itemCount: workers.length,
                      itemBuilder: (context, index) {
                        final worker = workers[index];
                        return Card(
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          margin: EdgeInsets.symmetric(vertical: 8.0),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Image
                                Container(
                                  width: 80,
                                  height: 80,
                                  decoration: BoxDecoration(
                                    color: Colors.orange[100],
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: Image.network(
                                      worker.image,
                                      fit: BoxFit.cover,
                                      errorBuilder: (
                                        context,
                                        error,
                                        stackTrace,
                                      ) {
                                        return Icon(
                                          Icons.person,
                                          size: 40,
                                          color: Colors.grey,
                                        );
                                      },
                                    ),
                                  ),
                                ),
                                SizedBox(width: 12),
                                // Info
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        worker.name,
                                        style: GoogleFonts.roboto(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      SizedBox(height: 6),
                                      Text(
                                        worker.location,
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: Colors.grey[700],
                                        ),
                                      ),
                                      SizedBox(height: 6),
                                      Container(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 20,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.red,
                                          borderRadius: BorderRadius.circular(
                                            11,
                                          ),
                                        ),
                                        child: Text(
                                          worker.date,
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // Buttons
                                Column(
                                  children: [
                                    TextButton(
                                      onPressed: () {
                                        // View logic here
                                      },
                                      child: Text(
                                        'View',
                                        style: TextStyle(
                                          color: Colors.green,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    InkWell(
                                      onTap: () {
                                        assignOrderToWorker(worker.id);
                                      },
                                      child: Container(
                                        height: 27,
                                        width: 70,
                                        decoration: BoxDecoration(
                                          color: Colors.green.shade700,
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            'Assign',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
          ),
        ],
      ),
    );
  }
}
