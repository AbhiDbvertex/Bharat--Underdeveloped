import 'dart:convert';

import 'package:developer/views/ServiceProvider/ServiceDisputeScreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/AppColors.dart';
import 'ServiceWorkerListScreen.dart';

class ServiceWorkDetailScreen extends StatefulWidget {
  final String orderId;

  const ServiceWorkDetailScreen({super.key, required this.orderId});

  @override
  State<ServiceWorkDetailScreen> createState() =>
      _ServiceWorkDetailScreenState();
}

class _ServiceWorkDetailScreenState extends State<ServiceWorkDetailScreen> {
  bool isLoading = true;
  Map<String, dynamic>? order;

  @override
  void initState() {
    super.initState();
    fetchOrderDetails();
  }

  Future<void> fetchOrderDetails() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("token");

      var headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };

      var body = jsonEncode({"order_id": widget.orderId});

      var response = await http.post(
        Uri.parse(
          "https://api.thebharatworks.com/api/direct-order/accept-offer",
        ),
        headers: headers,
        body: body,
      );

      var data = jsonDecode(response.body);
      if (response.statusCode == 200 && data["order"] != null) {
        setState(() {
          order = data["order"];
          isLoading = false;
        });
      } else {
        throw Exception(data["message"]);
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Failed to load work details.")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        title: const Text("Work Detail", style: TextStyle(color: Colors.white)),
      ),
      body:
          isLoading
              ? const Center(child: CircularProgressIndicator())
              : order == null
              ? const Center(child: Text("No data found"))
              : SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.network(
                      "https://api.thebharatworks.com${order!['image_url']}",
                      height: 200,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder:
                          (context, error, stackTrace) =>
                              Image.asset('assets/images/task.png'),
                    ),
                    const SizedBox(height: 20),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          order!['title'] ?? 'Work Title',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          "Posted Date: ${order!['deadline']?.substring(0, 10) ?? 'N/A'}",
                          style: const TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        order!['address'] ?? '',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 10),

                    Text(
                      "Completion Date: ${order!['deadline']?.substring(0, 10) ?? 'N/A'}",
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 10),

                    Text(
                      "Work Title",
                      style: GoogleFonts.roboto(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(order!['description'] ?? ''),
                    const SizedBox(height: 20),

                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) =>
                                    ServiceWorkerListScreen(), // pass data if needed
                          ),
                        );
                      },
                      child: Container(
                        height: 50,
                        width: 320,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.green.shade700),
                        ),
                        child: Center(
                          child: Text(
                            'Assign to another person',
                            style: GoogleFonts.roboto(
                              fontSize: 14,
                              color: Colors.green,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    /// ✅ Payment Card Dynamic
                    Card(
                      elevation: 6,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        width: 330,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.white,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Center(
                              child: Text(
                                'Payment',
                                style: GoogleFonts.roboto(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Divider(thickness: 0.8),
                            const SizedBox(height: 10),

                            if (order!['service_payment'] != null &&
                                order!['service_payment']['payment_history'] !=
                                    null &&
                                order!['service_payment']['payment_history']
                                    .isNotEmpty)
                              ...List.generate(
                                order!['service_payment']['payment_history']
                                    .length,
                                (index) {
                                  final item =
                                      order!['service_payment']['payment_history'][index];
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 10),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "${index + 1}.  ${item['stage'] ?? 'Stage'}",
                                          style: GoogleFonts.roboto(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              "${item['status'] == 'paid' ? 'Paid' : 'Pending'}",
                                              style: GoogleFonts.roboto(
                                                color:
                                                    item['status'] == 'paid'
                                                        ? Colors.green
                                                        : Colors.red,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            Text(
                                              "₹${item['amount']}",
                                              style: GoogleFonts.roboto(
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              )
                            else
                              Text(
                                'No payment history found.',
                                style: GoogleFonts.roboto(fontSize: 14),
                              ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),

                    /// ⚠️ Warning Box with Icon
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 320,
                          padding: const EdgeInsets.only(top: 40, bottom: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            color: Colors.yellow.shade100,
                          ),
                          child: Column(
                            children: [
                              const SizedBox(height: 10),
                              Text(
                                'Warning Message',
                                style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  color: Colors.red,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Lorem ipsum dolor sit amet consectetur.',
                                style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          top: -30,
                          left: 0,
                          right: 0,
                          child: Center(
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: Colors.white,
                              ),
                              child: Image.asset(
                                'assets/images/warning.png',
                                height: 70,
                                width: 70,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ServiceDisputeScreen(),
                          ),
                        );
                      },
                      child: Container(
                        width: 320,
                        height: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.red,
                        ),
                        child: Center(
                          child: Text(
                            'Cancel Task and create dispute',
                            style: GoogleFonts.roboto(
                              fontSize: 14,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),

                    /// ✅ Mark Complete
                    Container(
                      width: 320,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: Colors.green.shade700,
                      ),
                      child: Center(
                        child: Text(
                          'Mark as complete',
                          style: GoogleFonts.roboto(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
    );
  }
}
