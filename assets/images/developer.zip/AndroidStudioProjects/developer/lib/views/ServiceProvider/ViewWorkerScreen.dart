import 'dart:convert';

// import 'package:developer/views/CustomeRole/WorkerScreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/AppColors.dart';
import 'WorkerScreen.dart';

class ViewWorkerScreen extends StatefulWidget {
  final String workerId;
  const ViewWorkerScreen({super.key, required this.workerId});

  @override
  State<ViewWorkerScreen> createState() => _ViewWorkerScreenState();
}

class _ViewWorkerScreenState extends State<ViewWorkerScreen> {
  Map<String, dynamic>? worker;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchWorkerDetail();
  }

  Future<String?> getToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  Future<void> fetchWorkerDetail() async {
    final token = await getToken();
    if (token == null) {
      print("❌ Token not found in local storage");
      setState(() => isLoading = false);
      return;
    }

    final url = Uri.parse(
      'https://api.thebharatworks.com/api/worker/get/${widget.workerId}',
    );

    try {
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            worker = data['worker'];
            isLoading = false;
          });
        } else {
          print("❌ API error: ${data['message']}");
          setState(() => isLoading = false);
        }
      } else {
        print("❌ Server error: ${response.statusCode}");
        setState(() => isLoading = false);
      }
    } catch (e) {
      print('❌ Error fetching worker detail: $e');
      setState(() => isLoading = false);
    }
  }

  Widget _info(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "$label: ",
            style: GoogleFonts.roboto(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          Expanded(child: Text(value, style: GoogleFonts.roboto(fontSize: 16))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body:
          isLoading
              ? const Center(child: CircularProgressIndicator())
              : worker == null
              ? const Center(child: Text("Worker not found"))
              : SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => WorkerScreen(),
                              ),
                            );
                          },
                          child: const Icon(
                            Icons.arrow_back_outlined,
                            size: 22,
                          ),
                        ),

                        SizedBox(width: 90),

                        Text(
                          "View Details",
                          style: GoogleFonts.roboto(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Center(
                      child: CircleAvatar(
                        radius: 60,
                        backgroundColor: Colors.grey[300],
                        backgroundImage: NetworkImage(
                          "https://api.thebharatworks.com${worker!['image']}",
                        ),
                        onBackgroundImageError: (_, __) {},
                        child:
                            worker!['image'] == null
                                ? const Icon(Icons.person, size: 60)
                                : null,
                      ),
                    ),
                    const SizedBox(height: 30),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _info("Name", worker!['name']),
                          _info("Phone", worker!['phone']),
                          _info(
                            "DOB",
                            worker!['dob'].toString().substring(0, 10),
                          ),
                          _info("Address", worker!['address']),
                          _info("Status", worker!['verifyStatus']),
                          _info(
                            "Created At",
                            worker!['createdAt'].toString().substring(0, 10),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
    );
  }
}
