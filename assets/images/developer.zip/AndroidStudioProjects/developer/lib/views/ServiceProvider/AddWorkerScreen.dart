import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../../../Widgets/AppColors.dart';
import '../../controllers/AccountController/AddWorkerController.dart';

class AddWorkerScreen extends StatefulWidget {
  const AddWorkerScreen({super.key});

  @override
  State<AddWorkerScreen> createState() => _AddWorkerScreenState();
}

class _AddWorkerScreenState extends State<AddWorkerScreen> {
  final controller = AddWorkerController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  OutlineInputBorder _customBorder() {
    return OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: Colors.grey, width: 1),
    );
  }

  void _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        controller.dobController.text =
            '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: controller.formKey,
          child: Column(
            children: [
              const SizedBox(height: 20),
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Padding(
                      padding: EdgeInsets.only(left: 8.0),
                      child: Icon(Icons.arrow_back, size: 25),
                    ),
                  ),
                  const SizedBox(width: 70),
                  Text(
                    "Add Worker Details",
                    style: GoogleFonts.roboto(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              GestureDetector(
                onTap: () => controller.pickImage(setState),
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    ClipOval(
                      child:
                          controller.selectedImage != null
                              ? Image.file(
                                controller.selectedImage!,
                                width: 120,
                                height: 120,
                                fit: BoxFit.cover,
                              )
                              : Container(
                                width: 120,
                                height: 120,
                                color: Colors.grey[300],
                                child: const Icon(
                                  Icons.person,
                                  size: 60,
                                  color: Colors.white,
                                ),
                              ),
                    ),
                    Container(
                      height: 30,
                      width: 30,
                      decoration: const BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.edit,
                        size: 18,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),
              _buildTextField(controller.nameController, 'Name', (value) {
                if (value!.trim().isEmpty) return 'Name is required';
                return null;
              }),

              IntlPhoneField(
                decoration: InputDecoration(
                  hintText: 'Phone Number',
                  border: _customBorder(),
                  enabledBorder: _customBorder(),
                  focusedBorder: _customBorder(),
                ),
                initialCountryCode: 'IN',
                disableLengthCheck: true,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(10),
                ],
                onChanged: (phone) => controller.phone = phone.number,
                validator: (phone) {
                  final number = phone?.number ?? '';
                  if (number.trim().isEmpty) return 'Phone number is required';
                  if (!RegExp(r'^\d{10}$').hasMatch(number)) {
                    return 'Enter 10-digit phone number';
                  }
                  return null;
                },
              ),

              _buildTextField(
                controller.aadhaarController,
                'Aadhaar Number',
                (value) {
                  if (value!.isEmpty) return 'Aadhaar required';
                  if (!RegExp(r'^[0-9]{12}$').hasMatch(value)) {
                    return 'Must be 12 digits';
                  }
                  return null;
                },
                TextInputType.number,
                [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(12),
                ],
              ),

              GestureDetector(
                onTap: _selectDate,
                child: AbsorbPointer(
                  child: _buildTextField(
                    controller.dobController,
                    'Date of Birth (YYYY-MM-DD)',
                    (value) => value!.isEmpty ? 'DOB required' : null,
                  ),
                ),
              ),

              _buildTextField(
                controller.addressController,
                'Address',
                (value) => value!.isEmpty ? 'Address required' : null,
              ),

              const SizedBox(height: 30),
              SizedBox(
                height: 50,
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (controller.validateInputs()) {
                      final success = await controller.submitWorkerToAPI(
                        context,
                      );
                      if (success) {
                        Navigator.pop(
                          context,
                          true,
                        ); // ✅ Send true to refresh WorkerScreen
                      }
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text(
                    'Add',
                    style: TextStyle(fontSize: 15, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
    TextEditingController controller,
    String hint,
    String? Function(String?) validator, [
    TextInputType type = TextInputType.text,
    List<TextInputFormatter>? inputFormatters,
  ]) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        keyboardType: type,
        validator: validator,
        inputFormatters: inputFormatters,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(fontSize: 14, color: Colors.grey),
          border: _customBorder(),
          enabledBorder: _customBorder(),
          focusedBorder: _customBorder(),
        ),
      ),
    );
  }
}
