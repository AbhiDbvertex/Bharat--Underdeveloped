import 'dart:convert';
import 'dart:io';

import 'package:developer/views/auth/MapPickerScreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/AppColors.dart';

class PostTaskScreen extends StatefulWidget {
  const PostTaskScreen({super.key});

  @override
  State<PostTaskScreen> createState() => _PostTaskScreenState();
}

class _PostTaskScreenState extends State<PostTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  File? _selectedImage;
  DateTime? _selectedDate;

  final titleController = TextEditingController();
  final addressController = TextEditingController();
  final googleAddressController = TextEditingController();
  final descriptionController = TextEditingController();
  final costController = TextEditingController();

  String? selectedCategoryId;
  final List<Map<String, String>> categories = [
    {"id": "64f3b21c49f8a9b7e53a2c10", "name": "Home Repair"},
    {"id": "64f3b21c49f8a9b7e53a2c11", "name": "Gardening"},
    {"id": "64f3b21c49f8a9b7e53a2c12", "name": "Electrical"},
  ];

  final List<Map<String, String>> allSubCategories = [
    {"id": "64f3b22749f8a9b7e53a2c13", "name": "Plumbing"},
    {"id": "64f3b22749f8a9b7e53a2c14", "name": "Cleaning"},
    {"id": "64f3b22749f8a9b7e53a2c15", "name": "Painting"},
    {"id": "64f3b22749f8a9b7e53a2c16", "name": "Electrician"},
    {"id": "64f3b22749f8a9b7e53a2c17", "name": "Carpentry"},
  ];

  List<String> selectedSubCategoryIds = [];
  bool isSubCategoryExpanded = false;

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedImage = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
    );
    if (pickedImage != null) {
      setState(() => _selectedImage = File(pickedImage.path));
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _submitTask() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token') ?? '';

      String formattedDeadline =
          _selectedDate != null
              ? "${_selectedDate!.year}-${_selectedDate!.month.toString().padLeft(2, '0')}-${_selectedDate!.day.toString().padLeft(2, '0')}"
              : "2025-08-01";

      String? base64Image;
      if (_selectedImage != null) {
        final bytes = await _selectedImage!.readAsBytes();
        final mimeType = lookupMimeType(_selectedImage!.path) ?? 'image/jpeg';
        base64Image = "data:$mimeType;base64,${base64Encode(bytes)}";
      }

      final body = {
        "title": titleController.text.trim(),
        "category_id": selectedCategoryId,
        "sub_category_ids": selectedSubCategoryIds.join(','),
        "address": addressController.text.trim(),
        "google_address": googleAddressController.text.trim(),
        "description": descriptionController.text.trim(),
        "cost": costController.text.trim(),
        "deadline": formattedDeadline,
        if (base64Image != null) "image": base64Image,
      };

      final response = await http.post(
        Uri.parse("https://api.thebharatworks.com/api/bidding-order/create"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode(body),
      );

      if (!mounted) return;

      if (response.statusCode == 200 || response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("✅ Task Posted Successfully")),
        );
        Navigator.pop(context);
      } else if (response.statusCode == 401) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("🔒 Session expired. Please login again."),
          ),
        );
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("❌ Failed: ${response.body}")));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("❗ Error: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(
                      Icons.arrow_back_outlined,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(width: 86),
                  Text(
                    "Post New Task",
                    style: GoogleFonts.roboto(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildLabel("Enter Title"),
              _buildTextField(
                titleController,
                "Title of work",
                icon: Icons.title,
              ),
              _buildLabel("Select Category"),
              DropdownButtonFormField<String>(
                decoration: _inputDecoration(
                  "Choose category",
                  icon: Icons.category,
                ),
                value: selectedCategoryId,
                items:
                    categories.map((cat) {
                      return DropdownMenuItem(
                        value: cat['id'],
                        child: Text(cat['name']!),
                      );
                    }).toList(),
                onChanged:
                    (value) => setState(() => selectedCategoryId = value),
              ),
              _buildLabel("Select Sub Category"),
              GestureDetector(
                onTap:
                    () => setState(
                      () => isSubCategoryExpanded = !isSubCategoryExpanded,
                    ),
                child: _buildDropdownTile(selectedSubCategoryIds),
              ),
              if (isSubCategoryExpanded)
                ...allSubCategories.map(
                  (subCat) => CheckboxListTile(
                    title: Text(subCat['name']!),
                    value: selectedSubCategoryIds.contains(subCat['id']),
                    onChanged: (bool? value) {
                      setState(() {
                        if (value == true) {
                          selectedSubCategoryIds.add(subCat['id']!);
                        } else {
                          selectedSubCategoryIds.remove(subCat['id']!);
                        }
                      });
                    },
                  ),
                ),
              _buildLabel("Enter Full Address"),
              _buildTextField(
                addressController,
                "Full Address",
                icon: Icons.location_on,
              ),
              _buildLabel("Enter Google Location"),
              GestureDetector(
                onTap: () async {
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => MapPickerScreen()),
                  );
                  if (result != null && result is String) {
                    setState(() {
                      googleAddressController.text = result;
                    });
                  }
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: googleAddressController,
                    decoration: _inputDecoration(
                      "Location",
                      icon: Icons.my_location,
                    ),
                    validator:
                        (value) =>
                            value == null || value.isEmpty
                                ? "Required field"
                                : null,
                  ),
                ),
              ),
              _buildLabel("Task Description"),
              _buildTextField(
                descriptionController,
                "Describe your task",
                icon: Icons.description,
                maxLines: 4,
              ),
              _buildLabel("Estimated Cost"),
              _buildTextField(
                costController,
                "Cost in INR",
                icon: Icons.currency_rupee,
                keyboardType: TextInputType.number,
              ),
              _buildLabel("Select Deadline"),
              GestureDetector(
                onTap: () => _selectDate(context),
                child: AbsorbPointer(
                  child: TextFormField(
                    decoration: _inputDecoration(
                      "Select Deadline Date",
                      icon: Icons.calendar_today,
                    ),
                    controller: TextEditingController(
                      text:
                          _selectedDate == null
                              ? "2025-08-01"
                              : "${_selectedDate!.day}-${_selectedDate!.month}-${_selectedDate!.year}",
                    ),
                  ),
                ),
              ),
              _buildLabel("Upload Task Image"),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    ElevatedButton.icon(
                      onPressed: _pickImage,
                      icon: const Icon(Icons.upload),
                      label: const Text("Upload Work Photo"),
                    ),
                    const SizedBox(height: 8),
                    if (_selectedImage != null)
                      Image.file(_selectedImage!, height: 100),
                    Text(
                      "Upload (.png, .jpg, .jpeg) File (300px × 300px)",
                      style: GoogleFonts.roboto(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  minimumSize: const Size.fromHeight(50),
                ),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    if (selectedSubCategoryIds.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            "Please select at least one sub category",
                          ),
                        ),
                      );
                      return;
                    }
                    _submitTask();
                  }
                },
                child: const Text("Post Task", style: TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Text(
      text,
      style: GoogleFonts.roboto(fontSize: 14, fontWeight: FontWeight.w600),
    ),
  );

  InputDecoration _inputDecoration(String hint, {IconData? icon}) =>
      InputDecoration(
        hintText: hint,
        prefixIcon: icon != null ? Icon(icon) : null,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        contentPadding: const EdgeInsets.symmetric(
          vertical: 14,
          horizontal: 12,
        ),
      );

  Widget _buildTextField(
    TextEditingController controller,
    String hint, {
    int maxLines = 1,
    IconData? icon,
    TextInputType? keyboardType,
  }) => TextFormField(
    controller: controller,
    keyboardType: keyboardType,
    maxLines: maxLines,
    decoration: _inputDecoration(hint, icon: icon),
    validator:
        (value) => (value == null || value.isEmpty) ? "Required field" : null,
  );

  Widget _buildDropdownTile(List<String> selectedIds) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
    decoration: BoxDecoration(
      border: Border.all(color: Colors.grey.shade400),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            selectedIds.isEmpty
                ? "Choose sub categories"
                : selectedIds.join(', '),
            style: TextStyle(
              fontSize: 14,
              color: selectedIds.isEmpty ? Colors.grey : Colors.black,
            ),
          ),
        ),
        Icon(
          isSubCategoryExpanded ? Icons.arrow_drop_up : Icons.arrow_drop_down,
        ),
      ],
    ),
  );
}
