import 'dart:convert';

import 'package:developer/views/ServiceProvider/ServiceWorkDetailScreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../Consent/ApiEndpoint.dart';
import '../../Consent/app_constants.dart';
import '../../Widgets/AppColors.dart';
import '../../models/userModel/subCategoriesModel.dart';
import '../Account/service_provider_profile/ServiceProviderProfileScreen.dart';

class ServiceDirectViewScreen extends StatefulWidget {
  final String id;
  final String? categreyId;
  final String? subcategreyId;
  const ServiceDirectViewScreen({
    super.key,
    required this.id,
    this.categreyId,
    this.subcategreyId,
  });

  @override
  State<ServiceDirectViewScreen> createState() =>
      _ServiceDirectViewScreenState();
}

class _ServiceDirectViewScreenState extends State<ServiceDirectViewScreen> {
  bool isLoading = true;
  Map<String, dynamic>? order;
  Map<String, dynamic>? providerDetail;
  List<ServiceProviderModel> providerslist = [];
  String? orderProviderId;
  ScaffoldMessengerState? _scaffoldMessenger;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _scaffoldMessenger = ScaffoldMessenger.of(context); // Save reference
  }

  @override
  void initState() {
    super.initState();
    _clearHiredProviders().then((_) => fetchOrderDetail());
  }

  Future<void> fetchOrderDetail() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token') ?? '';
      print("Abhi:- fetchOrderDetail token: $token");

      final response = await http.get(
        Uri.parse(
          'https://api.thebharatworks.com/api/direct-order/getDirectOrderWithWorker/${widget.id}',
        ),
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        print("Abhi:- fetchOrderDetail response: ${response.body}");
        String? providerId;
        if (decoded['data']?['order']?['offer_history'] != null &&
            (decoded['data']['order']['offer_history'] as List).isNotEmpty &&
            decoded['data']['order']['offer_history'][0]['provider_id'] !=
                null) {
          providerId =
              decoded['data']['order']['offer_history'][0]['provider_id']['_id']
                  ?.toString();
          print("🚫 Order Provider ID set: $providerId");
        } else {
          print("⚠️ No provider_id found in offer_history");
        }
        setState(() {
          order = decoded['data']['order'];
          orderProviderId = providerId;
          isLoading = false;
        });

        if (providerId != null) {
          await _saveHiredProviderId(providerId);
          await fetchProviderById(providerId);
        }

        await fetchServiceProvidersListinWorkDetails(
          widget.categreyId,
          widget.subcategreyId,
        );
      } else {
        print(
          "❌ fetchOrderDetail failed: ${response.statusCode} - ${response.body}",
        );
        setState(() => isLoading = false);
        await fetchServiceProvidersListinWorkDetails(
          widget.categreyId,
          widget.subcategreyId,
        );
      }
    } catch (e) {
      print("❗ fetchOrderDetail Error: $e");
      setState(() => isLoading = false);
      await fetchServiceProvidersListinWorkDetails(
        widget.categreyId,
        widget.subcategreyId,
      );
    }
  }

  Future<void> fetchProviderById(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';

    final uri = Uri.parse(
      'https://api.thebharatworks.com/api/user/getServiceProvider/$id',
    );

    try {
      final response = await http.get(
        uri,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        setState(() {
          providerDetail = jsonData['user'];
        });
      } else {
        print("❌ Provider fetch failed: ${response.body}");
      }
    } catch (e) {
      print("❗ fetchProviderById Error: $e");
    }
  }

  Future<void> _saveHiredProviderId(String hiredId) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> hiredIds = prefs.getStringList('hiredProviderIds') ?? [];
    if (!hiredIds.contains(hiredId)) {
      hiredIds.add(hiredId);
      await prefs.setStringList('hiredProviderIds', hiredIds);
      print("🚫 Saved Hired Provider ID: $hiredId");
      print("🚫 Current hiredProviderIds: $hiredIds");
    }
  }

  Future<void> _clearHiredProviders() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('hiredProviderIds');
    print("🗑️ Cleared hiredProviderIds");
    if (order != null &&
        order!['service_payment'] != null &&
        order!['service_payment']['payment_history']?.isNotEmpty == true) {
      try {
        final response = await http.post(
          Uri.parse(
            'https://api.razorpay.com/v1/payments/${order!['service_payment']['payment_history'][0]['payment_id']}/refund',
          ),
          headers: {
            'Authorization':
                'Basic ${base64Encode(utf8.encode('YOUR_RAZORPAY_KEY_ID:YOUR_RAZORPAY_KEY_SECRET'))}',
          },
        );
        print("📤 Refund API response: ${response.body}");
      } catch (e) {
        print("❗ Refund Error: $e");
      }
    }
  }

  Future<void> fetchServiceProvidersListinWorkDetails(
    String? categoryId,
    String? subCategoryId,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    final hiredProviderIds = prefs.getStringList('hiredProviderIds') ?? [];
    print("🚫 Hired Provider IDs before fetch: $hiredProviderIds");

    if (token == null) {
      if (mounted && _scaffoldMessenger != null) {
        _scaffoldMessenger!.showSnackBar(
          const SnackBar(content: Text("Please login first")),
        );
      }
      return;
    }

    final uri = Uri.parse(
      '${AppConstants.baseUrl}${ApiEndpoint.serviceDirectViewScreen}',
    );

    try {
      final response = await http.post(
        uri,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
        body: json.encode({
          "category_id": categoryId,
          "subcategory_id": subCategoryId,
        }),
      );

      print("📦 fetchServiceProviders Status: ${response.statusCode}");
      print("📦 fetchServiceProviders Body: ${response.body}");
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data["status"] == true && data["data"] != null) {
          setState(() {
            providerslist =
                (data["data"] as List)
                    .map((json) {
                      final provider = ServiceProviderModel.fromJson(json);
                      bool isExcluded =
                          hiredProviderIds.contains(provider.id) ||
                          provider.id == orderProviderId;
                      print(
                        "🔍 Provider ID: ${provider.id}, Name: ${provider.fullName}, Excluded: $isExcluded",
                      );
                      return provider;
                    })
                    .where((provider) {
                      bool isValid =
                          provider.id != null &&
                          !hiredProviderIds.contains(provider.id) &&
                          provider.id != orderProviderId;
                      if (!isValid) {
                        print("🚫 Filtered out provider: ${provider.id}");
                      }
                      return isValid;
                    })
                    .toList();
            print("✅ Providers loaded: ${providerslist.length}");
            print(
              "✅ Providers IDs: ${providerslist.map((p) => p?.id).toList()}",
            );
          });
        } else {
          if (mounted && _scaffoldMessenger != null) {
            _scaffoldMessenger!.showSnackBar(
              const SnackBar(content: Text("No providers found.")),
            );
          }
        }
      } else {
        final err = json.decode(response.body);
        if (mounted && _scaffoldMessenger != null) {
          _scaffoldMessenger!.showSnackBar(
            SnackBar(
              content: Text("Error ${response.statusCode}: ${err['message']}"),
            ),
          );
        }
      }
    } catch (e) {
      print("❗ Exception: $e");
      if (mounted && _scaffoldMessenger != null) {
        _scaffoldMessenger!.showSnackBar(SnackBar(content: Text("Error: $e")));
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print(
      "Abhi:- DirectViewscreen get categreyId ${widget.categreyId} : subCategreyId : ${widget.subcategreyId}",
    );
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 10,
        automaticallyImplyLeading: false,
      ),
      body:
          isLoading
              ? const Center(child: CircularProgressIndicator())
              : order == null
              ? const Center(child: Text("No data found"))
              : SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 30),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: const Padding(
                            padding: EdgeInsets.only(left: 18.0),
                            child: Icon(Icons.arrow_back_outlined, size: 22),
                          ),
                        ),
                        const SizedBox(width: 90),
                        Text(
                          "Work details",
                          style: GoogleFonts.roboto(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    if (order!['image_url'] != null)
                      Image.network(
                        'https://api.thebharatworks.com${order!['image_url']}',
                        width: double.infinity,
                        height: 200,
                        fit: BoxFit.cover,
                        errorBuilder:
                            (context, error, stackTrace) => Image.asset(
                              'assets/images/task.png',
                              width: double.infinity,
                              height: 200,
                              fit: BoxFit.cover,
                            ),
                      ),
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            order!['title'] ?? '',
                            style: GoogleFonts.roboto(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: 24,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 40,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  color: Colors.red,
                                ),
                                child: Center(
                                  child: Text(
                                    order!['address'] ?? '',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                "Posted: ${order!['createdAt']?.toString().substring(0, 10) ?? ''}",
                                style: GoogleFonts.roboto(color: Colors.grey),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Completion: ${order!['deadline']?.toString().substring(0, 10) ?? ''}",
                            style: const TextStyle(color: Colors.black87),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Work title",
                            style: GoogleFonts.roboto(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            order!['description'] ??
                                "No description available.",
                            style: const TextStyle(fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        children: [
                          Container(
                            width: double.infinity,
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.green.shade700,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 6,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: GestureDetector(
                              onTap: () {
                                String orderId =
                                    "${order!['_id']}"; // ✅ Actual dynamic ID from API

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder:
                                        (context) => ServiceWorkDetailScreen(
                                          orderId: orderId,
                                        ),
                                  ),
                                );
                              },
                              child: Center(
                                child: Text(
                                  "Accept",
                                  style: GoogleFonts.roboto(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            width: double.infinity,
                            height: 50,
                            decoration: BoxDecoration(
                              color: const Color(0xFFEE2121),
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 6,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: TextButton(
                              onPressed: () async {
                                await _clearHiredProviders();
                                if (mounted && _scaffoldMessenger != null) {
                                  _scaffoldMessenger!.showSnackBar(
                                    const SnackBar(
                                      content: Text("Order cancelled"),
                                    ),
                                  );
                                }
                              },
                              child: Text(
                                "Reject",
                                style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    if (providerslist.isEmpty)
                      const Center(
                        child: Text(
                          "No providers available",
                          style: TextStyle(fontSize: 16, color: Colors.grey),
                        ),
                      )
                    else
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: providerslist.length,
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        itemBuilder: (context, index) {
                          final worker = providerslist[index];
                          final imageUrl =
                              worker.hisWork.isNotEmpty
                                  ? "https://api.thebharatworks.com/${worker.hisWork.first.replaceAll("\\", "/")}"
                                  : null;

                          return Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 6,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child:
                                      imageUrl != null
                                          ? Image.network(
                                            imageUrl,
                                            height: 120,
                                            width: 120,
                                            fit: BoxFit.cover,
                                            errorBuilder:
                                                (context, error, stackTrace) =>
                                                    const Icon(
                                                      Icons.broken_image,
                                                      size: 40,
                                                    ),
                                          )
                                          : Image.asset(
                                            "assets/images/account1.png",
                                            height: 80,
                                            width: 80,
                                            fit: BoxFit.cover,
                                          ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const SizedBox(height: 10),
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              worker.fullName ?? "Unknown",
                                              style: GoogleFonts.roboto(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 13,
                                              ),
                                            ),
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            children: [
                                              Row(
                                                children: [
                                                  Text(
                                                    worker.rating
                                                        .toStringAsFixed(1),
                                                    style: GoogleFonts.roboto(
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                    ),
                                                  ),
                                                  const Icon(
                                                    Icons.star,
                                                    size: 18,
                                                    color: Colors.yellow,
                                                  ),
                                                ],
                                              ),
                                              GestureDetector(
                                                onTap: () async {
                                                  final url =
                                                      "https://api.thebharatworks.com/api/user/getServiceProvider/${worker.id}";
                                                  try {
                                                    final prefs =
                                                        await SharedPreferences.getInstance();
                                                    final token = prefs
                                                        .getString('token');
                                                    if (token == null) {
                                                      if (mounted &&
                                                          _scaffoldMessenger !=
                                                              null) {
                                                        _scaffoldMessenger!
                                                            .showSnackBar(
                                                              const SnackBar(
                                                                content: Text(
                                                                  "User not logged in.",
                                                                ),
                                                              ),
                                                            );
                                                      }
                                                      return;
                                                    }
                                                    final response = await http
                                                        .get(
                                                          Uri.parse(url),
                                                          headers: {
                                                            'Content-Type':
                                                                'application/json',
                                                            'Authorization':
                                                                'Bearer $token',
                                                          },
                                                        );
                                                    if (response.statusCode ==
                                                        200) {
                                                      final data = jsonDecode(
                                                        response.body,
                                                      );
                                                      if (mounted) {
                                                        Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                            builder:
                                                                (_) =>
                                                                    SellerScreen(),
                                                          ),
                                                        );
                                                      }
                                                    } else {
                                                      if (mounted &&
                                                          _scaffoldMessenger !=
                                                              null) {
                                                        _scaffoldMessenger!
                                                            .showSnackBar(
                                                              SnackBar(
                                                                content: Text(
                                                                  "Failed: ${response.statusCode}",
                                                                ),
                                                              ),
                                                            );
                                                      }
                                                    }
                                                  } catch (e) {
                                                    if (mounted &&
                                                        _scaffoldMessenger !=
                                                            null) {
                                                      _scaffoldMessenger!
                                                          .showSnackBar(
                                                            SnackBar(
                                                              content: Text(
                                                                "Error: $e",
                                                              ),
                                                            ),
                                                          );
                                                    }
                                                  }
                                                },
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                        top: 8.0,
                                                      ),
                                                  child: Text(
                                                    'View Profile',
                                                    style: GoogleFonts.roboto(
                                                      fontSize: 11,
                                                      color:
                                                          Colors.green.shade700,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                      Text(
                                        "₹200.00",
                                        style: GoogleFonts.roboto(
                                          fontWeight: FontWeight.w500,
                                          color: Colors.grey[700],
                                          fontSize: 13,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        worker.skill ?? "No skill info",
                                        style: GoogleFonts.roboto(
                                          fontSize: 11,
                                          color: Colors.grey[700],
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 35,
                                              vertical: 4,
                                            ),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFF27773),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Text(
                                              worker.location ?? "No location",
                                              style: GoogleFonts.roboto(
                                                color: Colors.white,
                                                fontSize: 11,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
    );
  }
}
