import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../Widgets/AppColors.dart';

class ServiceDisputeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        centerTitle: true,
        elevation: 0,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 18.0),
                    child: const Icon(Icons.arrow_back_outlined, size: 22),
                  ),
                ),
                const SizedBox(width: 100),
                Text(
                  "Dispute",
                  style: GoogleFonts.roboto(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            SizedBox(height: 50),

            Text(
              'Enter Amount',
              style: GoogleFonts.roboto(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 50,
              width: 320,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey, width: 1.4),
                borderRadius: BorderRadius.circular(10),
              ),
            ),

            SizedBox(height: 20),

            // Description
            Text(
              'Description',
              style: GoogleFonts.roboto(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 110,
              width: 320,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey, width: 1.4),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            SizedBox(height: 20),

            // Requirement
            Text(
              'Requirement',
              style: GoogleFonts.roboto(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 110,
              width: 320,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey, width: 1.4),
                borderRadius: BorderRadius.circular(5),
              ),
            ),
            SizedBox(height: 20),

            // Upload Image
            Text(
              'Upload',
              style: GoogleFonts.roboto(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 90,
              width: 320,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey, width: 1.4),
                borderRadius: BorderRadius.circular(5),
              ),
              child: Center(
                child: Text(
                  'Upload Image',
                  style: TextStyle(fontSize: 20, color: Colors.green.shade700),
                ),
              ),
            ),
            SizedBox(height: 20),

            // Dispute Button
            Center(
              child: Container(
                height: 50,
                width: 180,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.green.shade700,
                ),
                child: Center(
                  child: Text(
                    'Dispute',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
